plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
    // ADDED: This connects your app to Firebase
    id("com.google.gms.google-services")
}

android {
    namespace = "com.llcet.app"
    
    // HARDCODED TO 36 TO FIX THE FLUTLAB ERROR
    compileSdk = 36 
    
    ndkVersion = flutter.ndkVersion

    compileOptions {
        // UPGRADED: AGP 8.9.1 requires Java 17
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.llcet.app"
        
        // REQUIRED: Firebase and PDF Printing require at least 21
        minSdk = 21
        
        // UPDATED: Hardcoding targetSdk to 36 to match compileSdk and prevent resource crashes
        targetSdk = 36
        
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        
        // REQUIRED: Handles the large number of library methods
        multiDexEnabled = true
    }

    buildTypes {
        release {
            // Using debug keys for your initial test APK
            signingConfig = signingConfigs.getByName("debug")
            
            // ADDED: Ensure resources are shrunk correctly to avoid build bloat
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

flutter {
    source = "../.."
}

// ADDED: This block forces the printing and firebase libraries to use the correct Android Core version
// This is the secondary fix for the 'lStar' resource crash.
configurations.all {
    resolutionStrategy {
        force("androidx.core:core:1.13.1")
        force("androidx.core:core-ktx:1.13.1")
    }
}