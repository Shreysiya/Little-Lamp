plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
    // ADDED: This connects your app to Firebase
    id("com.google.gms.google-services")
}

android {
    namespace = "com.llcet.connect"
    // UPGRADED: For compatibility with 2026 Android standards
    compileSdk = 35 
    ndkVersion = flutter.ndkVersion

    compileOptions {
        // UPGRADED: AGP 8.9.1 requires Java 17
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.llcet.connect"
        
        // REQUIRED: Firebase and PDF Printing require at least 21
        minSdk = 21
        
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        
        // REQUIRED: Handles the large number of library methods
        multiDexEnabled = true
    }

    buildTypes {
        release {
            // Using debug keys for your initial test APK
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}