pluginManagement {
    val flutterSdkPath = run {
        val properties = java.util.Properties()
        file("local.properties").inputStream().use { properties.load(it) }
        val flutterSdkPath = properties.getProperty("flutter.sdk")
        require(flutterSdkPath != null) { "flutter.sdk not set in local.properties" }
        flutterSdkPath
    }

    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    // UPGRADED: From 8.7.0 to 8.9.1 to fix the AndroidX metadata error
    id("com.android.application") version "8.9.1" apply false
    // UPGRADED: From 1.8.22 to 2.1.0 to meet 2026 Flutter standards
    id("org.jetbrains.kotlin.android") version "2.1.0" apply false
    // ADDED: Required for Firebase services
    id("com.google.gms.google-services") version "4.4.0" apply false
}

include(":app")