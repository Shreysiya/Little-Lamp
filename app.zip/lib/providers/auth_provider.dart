import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? _user;
  bool _isLoading = true;
  bool _isAdmin = false;
  String? _userName;
  String? _userStatus; // "pending" | "approved" | "rejected"

  User? get currentUser => _user;
  User? get user => _user;
  bool get isLoading => _isLoading;
  bool get isAdmin => _isAdmin;
  bool get isLoggedIn => _user != null;
  String? get userName => _userName;
  String? get userId => _user?.uid;
  String? get userStatus => _userStatus;

  AuthProvider() {
    _checkPersistence();
  }

  Future<void> _checkPersistence() async {
    _isLoading = true;
    notifyListeners();
    _user = _auth.currentUser;
    if (_user != null) {
      await _fetchUserData(_user!.uid);
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> _fetchUserData(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists) {
        final data = doc.data()!;
        _isAdmin = data['role'] == 'admin';
        // FIX: support both 'name' and 'fullName' fields
        _userName = (data['name'] ?? data['fullName'] ?? '').toString().trim();
        if (_userName!.isEmpty) _userName = null;
        _userStatus = data['status'] as String?;
      }
    } catch (e) {
      debugPrint('Error fetching user data: $e');
    }
  }

  Future<String?> signup({
    required String name,
    required String email,
    required String phone,
    required String address,
    required String password,
  }) async {
    try {
      _isLoading = true;
      notifyListeners();

      final cred = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);

      // FIX: save BOTH 'name' and 'fullName' so all parts of the app work
      await _firestore.collection('users').doc(cred.user!.uid).set({
        'name': name, // ✅ used by VolunteerModel & volunteer_provider
        'fullName': name, // ✅ used by AuthProvider & admin screens
        'email': email,
        'phone': phone,
        'address': address,
        'role': 'member',
        'status': 'pending',
        'joinedAt': FieldValue.serverTimestamp(),
        'approvedAt': null,
        'approvedBy': null,
      });

      _user = cred.user;
      _userName = name;
      _userStatus = 'pending';
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> login(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();
      final cred = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      _user = cred.user;
      await _fetchUserData(cred.user!.uid);
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    _user = null;
    _isAdmin = false;
    _userName = null;
    _userStatus = null;
    notifyListeners();
  }

  // FIX: refresh user status from Firestore (call after admin approves)
  Future<void> refreshUserStatus() async {
    if (_user == null) return;
    await _fetchUserData(_user!.uid);
    notifyListeners();
  }

  Future<String?> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      return null;
    } catch (e) {
      return e.toString();
    }
  }
}
