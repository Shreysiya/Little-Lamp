import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? _user;
  bool _isLoading = false;
  bool _isAdmin = false;
  String? _userName;

  User? get user => _user;
  bool get isLoading => _isLoading;
  bool get isAdmin => _isAdmin;
  bool get isLoggedIn => _user != null;
  String? get userName => _userName;

  // FIXED: Added userId getter for identification in Forum/Receipts
  String? get userId => _user?.uid;

  AuthProvider() {
    _checkPersistence();
  }

  Future<void> _checkPersistence() async {
    _user = _auth.currentUser;
    if (_user != null) {
      await _fetchUserData(_user!.uid);
    }
    notifyListeners();
  }

  Future<void> _fetchUserData(String uid) async {
    final doc = await _firestore.collection('users').doc(uid).get();
    if (doc.exists) {
      _isAdmin = doc.data()?['role'] == 'admin';
      _userName = doc.data()?['name'];
    }
  }

  Future<String?> signup({
    required String name,
    required String email,
    required String phone,
    required String address,
    required String password,
  }) async {
    try {
      _isLoading = true;
      notifyListeners();

      final cred = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);

      await _firestore.collection('users').doc(cred.user!.uid).set({
        'name': name,
        'email': email,
        'phone': phone,
        'address': address,
        'role': 'volunteer',
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });

      _user = cred.user;
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> login(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();
      final cred = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      await _fetchUserData(cred.user!.uid);
      _user = cred.user;
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    _user = null;
    notifyListeners();
  }

  Future<String?> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      return null;
    } catch (e) {
      return e.toString();
    }
  }
}
