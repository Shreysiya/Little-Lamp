import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/contribution_model.dart';

class VolunteerProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  List<ContributionModel> _myContributions = [];
  List<Map<String, dynamic>> _announcements = [];
  List<Map<String, dynamic>> _events = [];
  List<Map<String, dynamic>> _polls = [];

  bool _isLoading = false;
  double _yearlyTotal = 0.0;

  StreamSubscription? _paymentsSubscription;

  // Getters
  List<ContributionModel> get myContributions => _myContributions;
  List<Map<String, dynamic>> get announcements => _announcements;
  List<Map<String, dynamic>> get events => _events;
  List<Map<String, dynamic>> get polls => _polls;
  bool get isLoading => _isLoading;
  double get yearlyTotal => _yearlyTotal;

  // ── 1. START LISTENING ───────────────────────────────────────
  // FIX: Check auth before starting payment listener
  void startListening() {
    _listenToAnnouncements();
    _listenToEvents();
    _listenToPolls();
    // Only start payment listener if user is logged in
    if (_auth.currentUser != null) {
      _listenToPayments();
    } else {
      // Wait for auth state then start
      _auth.authStateChanges().firstWhere((u) => u != null).then((_) {
        _listenToPayments();
      }).catchError((_) {});
    }
  }

  // Call this on logout to cancel streams
  void stopListening() {
    _paymentsSubscription?.cancel();
    _paymentsSubscription = null;
    _myContributions = [];
    _yearlyTotal = 0.0;
    notifyListeners();
  }

  void _listenToAnnouncements() {
    _firestore
        .collection('announcements')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .listen((snap) {
      _announcements =
          snap.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      notifyListeners();
    });
  }

  void _listenToEvents() {
    _firestore
        .collection('events')
        .orderBy('date', descending: false)
        .snapshots()
        .listen((snap) {
      _events = snap.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      notifyListeners();
    });
  }

  void _listenToPolls() {
    _firestore
        .collection('polls')
        .where('isActive', isEqualTo: true)
        .snapshots()
        .listen((snap) {
      _polls = snap.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      notifyListeners();
    });
  }

  // FIX: Added orderBy + stored subscription for cleanup
  void _listenToPayments() {
    final user = _auth.currentUser;
    if (user == null) return;

    _paymentsSubscription?.cancel();
    _paymentsSubscription = _firestore
        .collection('contributions')
        .where('volunteerId', isEqualTo: user.uid)
        .orderBy('fiscalIndex')
        .snapshots()
        .listen((snap) {
      _myContributions = snap.docs
          .map((doc) => ContributionModel.fromMap(doc.id, doc.data()))
          .toList();

      _yearlyTotal = _myContributions
          .where((c) => c.status == 'Paid')
          .fold(0.0, (sum, item) => sum + item.amount);
      notifyListeners();
    });
  }

  // ── 2. REACTIONS & VOTING ────────────────────────────────────
  Future<void> reactToNews(String docId, String emoji) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _firestore.collection('announcements').doc(docId).set({
      'reactions': {uid: emoji}
    }, SetOptions(merge: true));
  }

  Future<void> castVote(String pollId, String choice) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    await _firestore.collection('polls').doc(pollId).set({
      'votes': {uid: choice}
    }, SetOptions(merge: true));
  }

  // ── 3. FETCH (kept for explicit refresh use) ─────────────────
  Future<void> fetchMyContributions(String academicYear) async {
    final user = _auth.currentUser;
    if (user == null) return;
    _isLoading = true;
    notifyListeners();
    try {
      final snapshot = await _firestore
          .collection('contributions')
          .where('volunteerId', isEqualTo: user.uid)
          .where('academicYear', isEqualTo: academicYear)
          .orderBy('fiscalIndex')
          .get();

      _myContributions = snapshot.docs
          .map((doc) => ContributionModel.fromMap(doc.id, doc.data()))
          .toList();

      _yearlyTotal = _myContributions
          .where((c) => c.status == 'Paid')
          .fold(0.0, (sum, item) => sum + item.amount);
    } catch (e) {
      debugPrint("Error fetching contributions: $e");
    }
    _isLoading = false;
    notifyListeners();
  }

  // ── 4. SUBMIT ────────────────────────────────────────────────
  // FIX: Now fetches and saves memberName so admin sees real name
  Future<void> submitContribution({
    required String month,
    required int fiscalIndex,
    required String academicYear,
    required double amount,
    required String transactionId,
  }) async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      _isLoading = true;
      notifyListeners();

      // Fetch member name from users collection
      String memberName = '';
      try {
        final userDoc =
            await _firestore.collection('users').doc(user.uid).get();
        if (userDoc.exists) {
          final data = userDoc.data() as Map<String, dynamic>;
          memberName =
              (data['name'] ?? data['fullName'] ?? '').toString().trim();
        }
        // Fallback to Firebase Auth display name
        if (memberName.isEmpty) {
          memberName = (user.displayName ?? '').trim();
        }
      } catch (_) {}

      await _firestore.collection('contributions').add({
        'volunteerId': user.uid,
        'memberName': memberName, // ✅ NOW SAVED — fixes admin Recent Activity
        'amount': amount,
        'month': month,
        'fiscalIndex': fiscalIndex,
        'academicYear': academicYear,
        'status': 'Awaiting Approval',
        'transactionId': transactionId,
        'submittedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint("Firestore Error: $e");
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
