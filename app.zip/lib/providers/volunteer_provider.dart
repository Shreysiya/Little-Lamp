import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/contribution_model.dart';

class VolunteerProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  List<ContributionModel> _myContributions = [];
  List<Map<String, dynamic>> _announcements = [];
  List<Map<String, dynamic>> _events = [];
  List<Map<String, dynamic>> _polls = [];

  bool _isLoading = false;
  double _yearlyTotal = 0.0;

  // Getters
  List<ContributionModel> get myContributions => _myContributions;
  List<Map<String, dynamic>> get announcements => _announcements;
  List<Map<String, dynamic>> get events => _events;
  List<Map<String, dynamic>> get polls => _polls;
  bool get isLoading => _isLoading;
  double get yearlyTotal => _yearlyTotal;

  // --- 1. THE START LISTENING METHOD ---
  // This initializes all real-time streams when the app starts
  void startListening() {
    _listenToAnnouncements();
    _listenToEvents();
    _listenToPolls();
    // We use a listener for payments so the UI updates instantly after admin approval
    _listenToPayments();
  }

  void _listenToAnnouncements() {
    _firestore
        .collection('announcements')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .listen((snap) {
      _announcements =
          snap.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      notifyListeners();
    });
  }

  void _listenToEvents() {
    _firestore
        .collection('events')
        .orderBy('date', descending: false)
        .snapshots()
        .listen((snap) {
      _events = snap.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      notifyListeners();
    });
  }

  void _listenToPolls() {
    _firestore
        .collection('polls')
        .where('isActive', isEqualTo: true)
        .snapshots()
        .listen((snap) {
      _polls = snap.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      notifyListeners();
    });
  }

  void _listenToPayments() {
    final user = _auth.currentUser;
    if (user == null) return;

    _firestore
        .collection('contributions')
        .where('volunteerId', isEqualTo: user.uid)
        .snapshots()
        .listen((snap) {
      _myContributions = snap.docs
          .map((doc) => ContributionModel.fromMap(doc.id, doc.data()))
          .toList();

      _yearlyTotal = _myContributions
          .where((c) => c.status == 'Paid')
          .fold(0.0, (sum, item) => sum + item.amount);
      notifyListeners();
    });
  }

  // --- 2. ACTIONS: REACTIONS & VOTING ---

  Future<void> reactToNews(String docId, String emoji) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    // Updates the specific reaction for this user in the map
    await _firestore.collection('announcements').doc(docId).set({
      'reactions': {uid: emoji}
    }, SetOptions(merge: true));
  }

  Future<void> castVote(String pollId, String choice) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    // Records the user's vote
    await _firestore.collection('polls').doc(pollId).set({
      'votes': {uid: choice}
    }, SetOptions(merge: true));
  }

  // --- 3. EXISTING FETCH LOGIC (KEPT AS PER YOUR FILE) ---
  Future<void> fetchMyContributions(String academicYear) async {
    final user = _auth.currentUser;
    if (user == null) return;
    _isLoading = true;
    try {
      final snapshot = await _firestore
          .collection('contributions')
          .where('volunteerId', isEqualTo: user.uid)
          .where('academicYear', isEqualTo: academicYear)
          .orderBy('fiscalIndex')
          .get();

      _myContributions = snapshot.docs
          .map((doc) => ContributionModel.fromMap(doc.id, doc.data()))
          .toList();

      _yearlyTotal = _myContributions
          .where((c) => c.status == 'Paid')
          .fold(0.0, (sum, item) => sum + item.amount);
    } catch (e) {
      debugPrint("Error fetching: $e");
    }
    _isLoading = false;
    notifyListeners();
  }

  // --- 4. EXISTING SUBMIT LOGIC (KEPT AS PER YOUR FILE) ---
  Future<void> submitContribution({
    required String month,
    required int fiscalIndex,
    required String academicYear,
    required double amount,
    required String transactionId,
  }) async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      _isLoading = true;
      notifyListeners();

      await _firestore.collection('contributions').add({
        'volunteerId': user.uid,
        'amount': amount,
        'month': month,
        'fiscalIndex': fiscalIndex,
        'academicYear': academicYear,
        'status': 'Awaiting Approval',
        'transactionId': transactionId,
        'submittedAt': FieldValue.serverTimestamp(),
      });

      // No need to call fetchMyContributions because _listenToPayments handles it in real-time
    } catch (e) {
      debugPrint("Firestore Error: $e");
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
