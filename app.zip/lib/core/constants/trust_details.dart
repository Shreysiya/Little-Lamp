class TrustDetails {
  // Use 'Path' because these are local files in your FlutLab assets folder
  static const String logoPath = "assets/logo.png";
  static const String qrCodePath = "assets/bank_qr.png";

  // Your Trust Info
  static const String upiId =
      "littllamp@indianbk"; // <--- Update this to your real UPI
  static const String trustName = "Little Lamp Charitable Educational Trust";
}
