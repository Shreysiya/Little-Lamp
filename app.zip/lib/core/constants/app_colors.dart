import 'package:flutter/material.dart';

class AppColors {
  // Brand Colors
  static const Color primary = Color(0xFF6C63FF);
  static const Color primaryDark = Color(0xFF4B44CC);
  static const Color primaryLight = Color(0xFFE8E6FF);

  // Status Colors (For Payments)
  static const Color success = Color(0xFF2ECC71); // Paid
  static const Color pending = Color(0xFFF1C40F); // Awaiting Approval
  static const Color error = Color(0xFFE74C3C); // Unpaid

  // Backgrounds
  static const Color background = Color(0xFFF8F9FA);
  static const Color cardBg = Color(0xFFFFFFFF);

  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF6C63FF), Color(0xFF4B44CC)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
