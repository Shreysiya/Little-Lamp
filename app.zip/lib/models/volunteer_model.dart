class VolunteerModel {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String address; // Added Address
  final String role;
  final String status;
  final DateTime joinedDate;

  VolunteerModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.address,
    this.role = 'volunteer',
    this.status = 'pending',
    required this.joinedDate,
  });

  factory VolunteerModel.fromMap(String id, Map<String, dynamic> map) {
    return VolunteerModel(
      id: id,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phone: map['phone'] ?? '',
      address: map['address'] ?? '',
      role: map['role'] ?? 'volunteer',
      status: map['status'] ?? 'pending',
      joinedDate: map['joinedDate'] != null
          ? DateTime.parse(map['joinedDate'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'address': address,
      'role': role,
      'status': status,
      'joinedDate': joinedDate.toIso8601String(),
    };
  }
}
