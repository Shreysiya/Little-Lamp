class ContributionModel {
  final String id;
  final String volunteerId;
  final double amount;
  final String month;
  final int fiscalIndex;
  final String academicYear;
  final String status;
  final String? screenshotUrl;
  final String transactionId; // Added for verification and PDF receipts

  ContributionModel({
    required this.id,
    required this.volunteerId,
    required this.amount,
    required this.month,
    required this.fiscalIndex,
    required this.academicYear,
    required this.status,
    this.screenshotUrl,
    required this.transactionId,
  });

  factory ContributionModel.fromMap(String id, Map<String, dynamic> map) {
    return ContributionModel(
      id: id,
      volunteerId: map['volunteerId'] ?? '',
      amount: (map['amount'] ?? 0.0).toDouble(),
      month: map['month'] ?? '',
      fiscalIndex: map['fiscalIndex'] ?? 0,
      academicYear: map['academicYear'] ?? '',
      status: map['status'] ?? 'Pending',
      screenshotUrl: map['screenshotUrl'],
      transactionId: map['transactionId'] ?? 'N/A', // Ensuring we have a string
    );
  }
}
