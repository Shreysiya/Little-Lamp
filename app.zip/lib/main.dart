import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

import 'core/theme/app_theme.dart';
import 'providers/auth_provider.dart';
import 'providers/volunteer_provider.dart';
import 'providers/expense_provider.dart';

// Auth Screens
import 'screen/auth/login_screen.dart';
import 'screen/auth/signup_screen.dart';
import 'screen/auth/pending_approval_screen.dart';

// Member & Admin Screens
import 'screen/volunteer/volunteer_home.dart';
import 'screen/admin/admin_home.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyBmkis05TKGVI4QUqTStrz_iIWOjo1P-q4",
        authDomain: "llcet-ngo.firebaseapp.com",
        projectId: "llcet-ngo",
        storageBucket: "llcet-ngo.firebasestorage.app",
        messagingSenderId: "830229615920",
        appId: "1:830229615920:web:35ed9149377721c55364f5",
      ),
    );
  } catch (e) {
    debugPrint("Firebase Initialization Error: $e");
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => VolunteerProvider()),
        ChangeNotifierProvider(create: (_) => ExpenseProvider()),
      ],
      child: MaterialApp(
        title: 'LLCET CONNECT',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        home: const AuthWrapper(),
        routes: {
          '/login': (_) => const LoginScreen(),
          '/signup': (_) => const SignupScreen(),
          '/pending-approval': (_) => const PendingApprovalScreen(),
          '/member-home': (_) => const VolunteerHome(),
          '/admin-home': (_) => const AdminHome(),
        },
      ),
    );
  }
}

// 🛡️ GATEKEEPER — handles stay-logged-in + role + status routing
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    // 1. Show spinner while checking session
    if (auth.isLoading) {
      return const Scaffold(
        backgroundColor: Color(0xFFEDE6FF),
        body: Center(
          child: CircularProgressIndicator(
            color: Color(0xFF5B2D8E),
            strokeWidth: 2.5,
          ),
        ),
      );
    }

    // 2. Not logged in → Login screen
    if (!auth.isLoggedIn) {
      return const LoginScreen();
    }

    // 3. Admin → Admin dashboard
    if (auth.isAdmin) {
      return const AdminHome();
    }

    // 4. Member pending → Pending approval screen
    if (auth.userStatus == 'pending') {
      return const PendingApprovalScreen();
    }

    // 5. Member rejected → Login (with message handled in login)
    if (auth.userStatus == 'rejected') {
      return const LoginScreen();
    }

    // 6. Member approved → Member home
    return const VolunteerHome();
  }
}
