import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

// Importing our "Skin" and "Brain"
import 'core/theme/app_theme.dart';
import 'providers/auth_provider.dart';
import 'providers/volunteer_provider.dart';
import 'providers/expense_provider.dart';

// Importing Screens (We will create these files next)
import 'screen/auth/login_screen.dart';
import 'screen/volunteer/volunteer_home.dart';
import 'screen/admin/admin_home.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ✅ CONNECTING YOUR FIREBASE (Old configuration applied to new app)
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyBmkis05TKGVI4QUqTStrz_iIWOjo1P-q4",
        authDomain: "llcet-ngo.firebaseapp.com",
        projectId: "llcet-ngo",
        storageBucket: "llcet-ngo.firebasestorage.app",
        messagingSenderId: "830229615920",
        appId: "1:830229615920:web:35ed9149377721c55364f5",
      ),
    );
  } catch (e) {
    debugPrint("Firebase Initialization Error: $e");
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      // The "Central Nervous System" of the app
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => VolunteerProvider()),
        ChangeNotifierProvider(create: (_) => ExpenseProvider()),
      ],
      child: MaterialApp(
        title: 'LLCET CONNECT',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme, // Apply the "Shopping App" look
        home: const AuthWrapper(),
      ),
    );
  }
}

// 🛡️ THE GATEKEEPER: This handles the "Stay Logged In" logic
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    // 1. Show a smooth loading spinner while checking the session
    if (auth.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    // 2. If NOT logged in, send them to the Login Screen
    if (!auth.isLoggedIn) {
      return const LoginScreen();
    }

    // 3. If Logged in, send them to the correct Home based on their Role
    return auth.isAdmin ? const AdminHome() : const VolunteerHome();
  }
}
