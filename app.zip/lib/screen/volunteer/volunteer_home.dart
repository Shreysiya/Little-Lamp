import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../providers/auth_provider.dart';
import '../../providers/volunteer_provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/trust_details.dart';
import '../../models/contribution_model.dart';

class VolunteerHome extends StatefulWidget {
  const VolunteerHome({super.key});
  @override
  State<VolunteerHome> createState() => _VolunteerHomeState();
}

class _VolunteerHomeState extends State<VolunteerHome> {
  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    context.read<VolunteerProvider>().startListening();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const AnnouncementsTab(),
      const PaymentsTab(),
      const EventsTab(),
      const ForumTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(_getAppBarTitle()),
        actions: [
          IconButton(
              onPressed: () => context.read<AuthProvider>().logout(),
              icon: const Icon(Icons.logout))
        ],
      ),
      body: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300), child: pages[_tabIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.campaign_outlined), label: 'News'),
          NavigationDestination(
              icon: Icon(Icons.account_balance_wallet_outlined),
              label: 'Payments'),
          NavigationDestination(
              icon: Icon(Icons.event_note_outlined), label: 'Events'),
          NavigationDestination(
              icon: Icon(Icons.thumbs_up_down_outlined), label: 'Forum'),
        ],
      ),
    );
  }

  String _getAppBarTitle() {
    if (_tabIndex == 0) return "Trust Announcements";
    if (_tabIndex == 1) return "FY 2026-2027 Payments";
    if (_tabIndex == 2) return "Events Calendar";
    return "Volunteer Forum";
  }
}

class AnnouncementsTab extends StatelessWidget {
  const AnnouncementsTab({super.key});
  @override
  Widget build(BuildContext context) {
    final news = context.watch<VolunteerProvider>().announcements;
    if (news.isEmpty)
      return const Center(child: Text("No news from Admin yet."));

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: news.length,
      itemBuilder: (context, i) {
        final item = news[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListTile(
                title: Text(item['title'] ?? '',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(DateFormat('dd MMM, hh:mm a')
                    .format((item['createdAt'] as Timestamp).toDate())),
              ),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(item['content'] ?? '')),
              const Divider(),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: Row(
                  children: ["👍", "❤️", "👏"].map((emoji) {
                    final reactions = item['reactions'] as Map? ?? {};
                    int count =
                        reactions.values.where((v) => v == emoji).length;
                    return ActionChip(
                      label: Text("$emoji $count"),
                      onPressed: () => context
                          .read<VolunteerProvider>()
                          .reactToNews(item['id'], emoji),
                    );
                  }).toList(),
                ),
              )
            ],
          ),
        );
      },
    );
  }
}

class PaymentsTab extends StatelessWidget {
  const PaymentsTab({super.key});

  Future<void> _launchUPI(BuildContext context) async {
    final String upiUrl =
        'upi://pay?pa=${TrustDetails.upiId}&pn=${Uri.encodeComponent(TrustDetails.trustName)}&cu=INR';
    final Uri url = Uri.parse(upiUrl);
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        throw 'Could not launch';
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text("No UPI apps found.")));
      }
    }
  }

  // FIXED: PDF Syntax Corrected
  Future<void> _generateReceipt(
      BuildContext context, String month, double amount, String transId) async {
    final pdf = pw.Document();
    final auth = context.read<AuthProvider>();

    pdf.addPage(pw.Page(
      build: (pw.Context context) => pw.Center(
        child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.center,
          children: [
            pw.Text(TrustDetails.trustName,
                style:
                    pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
            pw.Divider(),
            pw.SizedBox(height: 10),
            pw.Text("OFFICIAL PAYMENT RECEIPT",
                style: pw.TextStyle(fontSize: 18)),
            pw.SizedBox(height: 30),
            pw.Text("Volunteer: ${auth.userName}"),
            pw.Text("Period: $month 2026-27"),
            pw.Text("Amount Paid: INR $amount"),
            pw.Text("Trans ID: $transId"),
            pw.SizedBox(height: 50),
            pw.Text("This is a computer-generated receipt for LLCET Trust.",
                style: pw.TextStyle(fontSize: 10)),
          ],
        ),
      ),
    ));

    await Printing.sharePdf(
        bytes: await pdf.save(), filename: 'LLCET_Receipt_$month.pdf');
  }

  void _showPaymentDialog(BuildContext context, String month, int index) {
    final transIdController = TextEditingController();
    final amtController = TextEditingController(text: "500");
    final volunteerProvider = context.read<VolunteerProvider>();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 24,
            right: 24,
            top: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Payment for $month",
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            Image.asset(TrustDetails.qrCodePath, height: 160),
            const SizedBox(height: 15),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.send_to_mobile),
                label: const Text("PAY USING ANY UPI APP"),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade700,
                    foregroundColor: Colors.white),
                onPressed: () => _launchUPI(context),
              ),
            ),
            const Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Text("OR",
                    style: TextStyle(color: Colors.grey, fontSize: 12))),
            TextField(
                controller: amtController,
                decoration: const InputDecoration(
                    labelText: "Amount", border: OutlineInputBorder()),
                keyboardType: TextInputType.number),
            const SizedBox(height: 10),
            TextField(
                controller: transIdController,
                decoration: const InputDecoration(
                    labelText: "12-Digit Trans ID",
                    border: OutlineInputBorder()),
                keyboardType: TextInputType.number),
            const SizedBox(height: 15),
            ElevatedButton(
              onPressed: () async {
                if (transIdController.text.length < 6) return;
                Navigator.pop(context);
                await volunteerProvider.submitContribution(
                  month: month,
                  fiscalIndex: index,
                  academicYear: "2026-2027",
                  amount: double.parse(amtController.text),
                  transactionId: transIdController.text,
                );
              },
              child: const Text("SUBMIT RECORD"),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<VolunteerProvider>();
    final months = [
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "January",
      "February",
      "March"
    ];
    DateTime now = DateTime.now();
    int currentMonthIdx = (now.month >= 4) ? (now.month - 4) : (now.month + 8);

    List<String> missedMonths = [];
    for (int i = 0; i <= currentMonthIdx; i++) {
      if (_getPaymentStatus(provider.myContributions, i) == 'Pending') {
        if (i < currentMonthIdx || (i == currentMonthIdx && now.day >= 10)) {
          missedMonths.add(months[i]);
        }
      }
    }

    return Column(
      children: [
        if (missedMonths.isNotEmpty)
          Container(
            width: double.infinity,
            color: Colors.red.shade50,
            padding: const EdgeInsets.all(12),
            child: Text("🚨 Missed: ${missedMonths.join(', ')}",
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    fontSize: 12)),
          ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, childAspectRatio: 1.1),
            itemCount: 12,
            itemBuilder: (context, i) {
              final contrib = provider.myContributions
                  .where((c) => c.fiscalIndex == i)
                  .firstOrNull;
              final status = contrib?.status ?? 'Pending';
              return Card(
                color: status == 'Paid' ? Colors.green.shade50 : Colors.white,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("${months[i]}-${i < 9 ? '2026' : '2027'}",
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(status,
                        style: TextStyle(
                            fontSize: 12,
                            color: status == 'Paid'
                                ? Colors.green
                                : Colors.orange)),
                    if (status == 'Paid')
                      IconButton(
                          icon: const Icon(Icons.picture_as_pdf,
                              color: Colors.red),
                          onPressed: () => _generateReceipt(context, months[i],
                              contrib!.amount, contrib.transactionId)),
                    if (status == 'Pending')
                      TextButton(
                          onPressed: () =>
                              _showPaymentDialog(context, months[i], i),
                          child: const Text("PAY NOW")),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  String _getPaymentStatus(List<ContributionModel> contribs, int index) {
    final match = contribs.where((c) => c.fiscalIndex == index).toList();
    return match.isEmpty ? 'Pending' : match.first.status;
  }
}

class EventsTab extends StatelessWidget {
  const EventsTab({super.key});
  @override
  Widget build(BuildContext context) {
    final events = context.watch<VolunteerProvider>().events;
    final now = DateTime.now();
    final upcoming = events
        .where((e) => (e['date'] as Timestamp).toDate().isAfter(now))
        .toList();
    final past = events
        .where((e) => (e['date'] as Timestamp).toDate().isBefore(now))
        .toList();

    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          const TabBar(tabs: [Tab(text: "Upcoming"), Tab(text: "Past Events")]),
          Expanded(
              child: TabBarView(
                  children: [_buildList(upcoming), _buildList(past)])),
        ],
      ),
    );
  }

  Widget _buildList(List list) {
    if (list.isEmpty) return const Center(child: Text("No events found."));
    return ListView.builder(
      itemCount: list.length,
      itemBuilder: (context, i) => ListTile(
        title: Text(list[i]['title'] ?? 'Event'),
        subtitle: Text(DateFormat('dd MMM yyyy')
            .format((list[i]['date'] as Timestamp).toDate())),
        leading: const Icon(Icons.event),
      ),
    );
  }
}

class ForumTab extends StatelessWidget {
  const ForumTab({super.key});
  @override
  Widget build(BuildContext context) {
    final polls = context.watch<VolunteerProvider>().polls;
    if (polls.isEmpty) return const Center(child: Text("No active polls."));

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: polls.length,
      itemBuilder: (context, i) {
        final poll = polls[i];
        final uid = context.read<AuthProvider>().userId;
        final hasVoted = (poll['votes'] as Map? ?? {}).containsKey(uid);

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Text(poll['question'] ?? '',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 15),
                if (hasVoted)
                  const Text("✅ Vote recorded. Thank you!",
                      style: TextStyle(color: Colors.green))
                else
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                          onPressed: () => context
                              .read<VolunteerProvider>()
                              .castVote(poll['id'], 'Yes'),
                          child: const Text("I'M IN")),
                      OutlinedButton(
                          onPressed: () => context
                              .read<VolunteerProvider>()
                              .castVote(poll['id'], 'No'),
                          child: const Text("NO")),
                    ],
                  )
              ],
            ),
          ),
        );
      },
    );
  }
}
