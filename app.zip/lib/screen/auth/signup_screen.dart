import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../core/constants/app_colors.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  bool _nameFocused = false;
  bool _emailFocused = false;
  bool _phoneFocused = false;
  bool _addressFocused = false;
  bool _passwordFocused = false;
  bool _obscureConfirmPassword = true;
  bool _confirmPasswordFocused = false;
  final _confirmPasswordController = TextEditingController();

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  // ── G4 Light Design Tokens ───────────────────────────────
  static const Color _bg = Color(0xFFEDE6FF);
  static const Color _deepPurple = Color(0xFF2D1B4E);
  static const Color _purple = Color(0xFF5B2D8E);
  static const Color _midPurple = Color(0xFF6B5A8A);
  static const Color _orange = Color(0xFFF5840C);
  static const Color _blue = Color(0xFF5BAEE8);
  // ─────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _slideController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _slideController, curve: Curves.easeOutCubic));
    Future.delayed(const Duration(milliseconds: 100), () {
      _fadeController.forward();
      _slideController.forward();
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  // ── VALIDATION ───────────────────────────────────────────
  String? _validateName(String? v) {
    if (v == null || v.trim().isEmpty) return 'Full name is required';
    if (v.trim().length < 3) return 'Name must be at least 3 characters';
    return null;
  }

  String? _validateEmail(String? v) {
    if (v == null || v.trim().isEmpty) return 'Email is required';
    final emailReg = RegExp(r'^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}$');
    if (!emailReg.hasMatch(v.trim())) return 'Enter a valid email address';
    return null;
  }

  String? _validatePhone(String? v) {
    if (v == null || v.trim().isEmpty) return 'Mobile number is required';
    final phoneReg = RegExp(r'^[6-9]\d{9}$');
    if (!phoneReg.hasMatch(v.trim()))
      return 'Enter a valid 10-digit Indian mobile number';
    return null;
  }

  String? _validateAddress(String? v) {
    if (v == null || v.trim().isEmpty) return 'Address is required';
    if (v.trim().length < 10) return 'Please enter your full address';
    return null;
  }

  String? _validatePassword(String? v) {
    if (v == null || v.isEmpty) return 'Password is required';
    if (v.length < 6) return 'Password must be at least 6 characters';
    return null;
  }

  String? _validateConfirmPassword(String? v) {
    if (v == null || v.isEmpty) return 'Please confirm your password';
    if (v != _passwordController.text) return 'Passwords do not match';
    return null;
  }

  // ── SUBMIT ───────────────────────────────────────────────
  void _handleSignup() async {
    if (!_formKey.currentState!.validate()) return;
    HapticFeedback.lightImpact();

    final auth = context.read<AuthProvider>();
    final error = await auth.signup(
      name: _nameController.text.trim(),
      email: _emailController.text.trim(),
      phone: _phoneController.text.trim(),
      address: _addressController.text.trim(),
      password: _passwordController.text,
    );

    if (!mounted) return;

    if (error == null) {
      // Navigate to pending approval screen — do not pop back to login
      Navigator.pushReplacementNamed(context, '/pending-approval');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.error_outline_rounded,
                  color: Colors.white, size: 18),
              const SizedBox(width: 10),
              Expanded(
                  child: Text(error,
                      style: const TextStyle(fontWeight: FontWeight.w500))),
            ],
          ),
          backgroundColor: const Color(0xFFD32F2F),
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = context.watch<AuthProvider>().isLoading;
    final size = MediaQuery.of(context).size;

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ));

    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // ── BACKGROUND ──────────────────────────────────
          Container(width: size.width, height: size.height, color: _bg),

          // ── AMBIENT ORB — top right orange ──────────────
          Positioned(
            top: -30,
            right: -40,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [_orange.withOpacity(0.16), Colors.transparent],
                ),
              ),
            ),
          ),

          // ── AMBIENT ORB — bottom left blue ──────────────
          Positioned(
            bottom: 80,
            left: -45,
            child: Container(
              width: 190,
              height: 190,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [_blue.withOpacity(0.16), Colors.transparent],
                ),
              ),
            ),
          ),

          // ── MAIN CONTENT ────────────────────────────────
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SlideTransition(
                position: _slideAnim,
                child: Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      children: [
                        // ── TOP BAR ──────────────────────
                        Padding(
                          padding: const EdgeInsets.fromLTRB(8, 12, 20, 0),
                          child: Row(
                            children: [
                              IconButton(
                                onPressed: () => Navigator.pop(context),
                                icon: const Icon(
                                    Icons.arrow_back_ios_new_rounded,
                                    color: _deepPurple,
                                    size: 20),
                              ),
                              const Spacer(),
                              Image.asset('assets/logo.png',
                                  height: 36, fit: BoxFit.contain),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // ── HEADER ───────────────────────
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 26),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Join LLCET",
                                style: GoogleFonts.poppins(
                                  color: _deepPurple,
                                  fontSize: 26,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              const SizedBox(height: 4),
                              _buildDividerRow(),
                              const SizedBox(height: 8),
                              Text(
                                "Together We Can Make a Difference",
                                style: TextStyle(
                                  color: _midPurple,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        // ── FORM CARD ────────────────────
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 18),
                          child: _buildFormCard(isLoading),
                        ),

                        const SizedBox(height: 20),

                        // ── LOGIN ROW ────────────────────
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Already a member? ",
                              style: TextStyle(
                                color: _midPurple,
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: _purple.withOpacity(0.10),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                      color: _purple.withOpacity(0.3),
                                      width: 1),
                                ),
                                child: Text(
                                  "Sign In",
                                  style: TextStyle(
                                    color: _purple,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── DIVIDER ROW ───────────────────────────────────────────
  Widget _buildDividerRow() {
    return Row(
      children: [
        Container(
          width: 30,
          height: 1.5,
          decoration: BoxDecoration(
            color: _blue.withOpacity(0.6),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Container(
          width: 7,
          height: 7,
          decoration: BoxDecoration(
            color: _orange,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                  color: _orange.withOpacity(0.5),
                  blurRadius: 6,
                  spreadRadius: 1),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Container(
          width: 30,
          height: 1.5,
          decoration: BoxDecoration(
            color: _blue.withOpacity(0.6),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ],
    );
  }

  // ── GLASS FORM CARD ───────────────────────────────────────
  Widget _buildFormCard(bool isLoading) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(26),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.62),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: Colors.white.withOpacity(0.95), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _purple.withOpacity(0.10),
              blurRadius: 32,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Member Application",
                style: GoogleFonts.poppins(
                  color: _deepPurple,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "Your journey with LLCET starts here",
                style: TextStyle(
                  color: _midPurple,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 22),

              // Full Name
              _buildField(
                controller: _nameController,
                label: "FULL NAME",
                hint: "e.g. Benny Joseph",
                icon: Icons.person_outline_rounded,
                isFocused: _nameFocused,
                onFocusChange: (v) => setState(() => _nameFocused = v),
                validator: _validateName,
                inputType: TextInputType.name,
                capitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 14),

              // Mobile Number
              _buildField(
                controller: _phoneController,
                label: "INDIAN MOBILE NUMBER",
                hint: "10-digit mobile number",
                icon: Icons.phone_android_rounded,
                isFocused: _phoneFocused,
                onFocusChange: (v) => setState(() => _phoneFocused = v),
                validator: _validatePhone,
                inputType: TextInputType.phone,
                maxLength: 10,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                prefix: Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: Text(
                    "+91  |  ",
                    style: TextStyle(
                      color: _purple,
                      fontWeight: FontWeight.w600,
                      fontSize: 13.5,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // Email
              _buildField(
                controller: _emailController,
                label: "EMAIL ADDRESS",
                hint: "you@example.com",
                icon: Icons.mail_outline_rounded,
                isFocused: _emailFocused,
                onFocusChange: (v) => setState(() => _emailFocused = v),
                validator: _validateEmail,
                inputType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 14),

              // Address
              _buildField(
                controller: _addressController,
                label: "FULL ADDRESS",
                hint: "House No., Street, City, Pincode",
                icon: Icons.location_on_outlined,
                isFocused: _addressFocused,
                onFocusChange: (v) => setState(() => _addressFocused = v),
                validator: _validateAddress,
                inputType: TextInputType.streetAddress,
                maxLines: 3,
                capitalization: TextCapitalization.sentences,
              ),
              const SizedBox(height: 14),

              // Password
              _buildField(
                controller: _passwordController,
                label: "CREATE PASSWORD",
                hint: "Minimum 6 characters",
                icon: Icons.lock_outline_rounded,
                isFocused: _passwordFocused,
                onFocusChange: (v) => setState(() => _passwordFocused = v),
                validator: _validatePassword,
                isPassword: true,
                obscure: _obscurePassword,
                onToggleObscure: () =>
                    setState(() => _obscurePassword = !_obscurePassword),
              ),

              const SizedBox(height: 6),

              // Terms note
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.info_outline_rounded,
                        size: 14, color: _midPurple),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        "Your account will be reviewed and activated by the LLCET admin.",
                        style: TextStyle(
                          color: _midPurple,
                          fontSize: 11,
                          fontWeight: FontWeight.w400,
                          height: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 6),

              const SizedBox(height: 14),

              // Confirm Password
              _buildField(
                controller: _confirmPasswordController,
                label: "CONFIRM PASSWORD",
                hint: "Re-enter your password",
                icon: Icons.lock_outline_rounded,
                isFocused: _confirmPasswordFocused,
                onFocusChange: (v) =>
                    setState(() => _confirmPasswordFocused = v),
                validator: _validateConfirmPassword,
                isPassword: true,
                obscure: _obscureConfirmPassword,
                onToggleObscure: () => setState(
                    () => _obscureConfirmPassword = !_obscureConfirmPassword),
              ),

              const SizedBox(height: 6),

              // Submit Button
              isLoading
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        child: CircularProgressIndicator(
                          color: _purple,
                          strokeWidth: 2.5,
                        ),
                      ),
                    )
                  : _buildSubmitButton(),
            ],
          ),
        ),
      ),
    );
  }

  // ── INPUT FIELD ───────────────────────────────────────────
  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    required bool isFocused,
    required ValueChanged<bool> onFocusChange,
    required String? Function(String?) validator,
    TextInputType inputType = TextInputType.text,
    bool isPassword = false,
    bool? obscure,
    VoidCallback? onToggleObscure,
    int maxLines = 1,
    int? maxLength,
    TextCapitalization capitalization = TextCapitalization.none,
    List<TextInputFormatter>? inputFormatters,
    Widget? prefix,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: _purple,
            fontSize: 9.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.0,
          ),
        ),
        const SizedBox(height: 6),
        Focus(
          onFocusChange: onFocusChange,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              color: isFocused
                  ? _purple.withOpacity(0.05)
                  : Colors.white.withOpacity(0.75),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(
                color: isFocused ? _purple : _purple.withOpacity(0.12),
                width: isFocused ? 1.8 : 1.5,
              ),
            ),
            child: TextFormField(
              controller: controller,
              obscureText: isPassword ? (obscure ?? true) : false,
              keyboardType: inputType,
              maxLines: isPassword ? 1 : maxLines,
              maxLength: maxLength,
              textCapitalization: capitalization,
              inputFormatters: inputFormatters,
              validator: validator,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              style: const TextStyle(
                fontSize: 13.5,
                color: _deepPurple,
                fontWeight: FontWeight.w500,
              ),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(
                  color: Color(0xFF8872AA),
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                ),
                counterText: '',
                prefixIcon: prefix != null
                    ? Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 13, right: 4),
                            child: Icon(icon,
                                color: isFocused
                                    ? _purple
                                    : _purple.withOpacity(0.35),
                                size: 19),
                          ),
                          prefix,
                        ],
                      )
                    : Padding(
                        padding: EdgeInsets.only(
                          left: 13,
                          right: 9,
                          bottom: maxLines > 1 ? 40 : 0,
                        ),
                        child: Icon(icon,
                            color:
                                isFocused ? _purple : _purple.withOpacity(0.35),
                            size: 19),
                      ),
                prefixIconConstraints:
                    const BoxConstraints(minWidth: 0, minHeight: 0),
                suffixIcon: isPassword
                    ? IconButton(
                        onPressed: onToggleObscure,
                        icon: Icon(
                          obscure ?? true
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined,
                          color: _purple.withOpacity(0.4),
                          size: 19,
                        ),
                      )
                    : null,
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  vertical: maxLines > 1 ? 14 : 14,
                  horizontal: 4,
                ),
                errorStyle: const TextStyle(
                  color: Color(0xFFB00020),
                  fontSize: 10.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── SUBMIT BUTTON ─────────────────────────────────────────
  Widget _buildSubmitButton() {
    return GestureDetector(
      onTap: _handleSignup,
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF3B1A6B), Color(0xFF5B2D8E), Color(0xFF7B3FAF)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: _purple.withOpacity(0.40),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "CREATE ACCOUNT",
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.22),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.arrow_forward_rounded,
                  color: Colors.white, size: 15),
            ),
          ],
        ),
      ),
    );
  }
}
