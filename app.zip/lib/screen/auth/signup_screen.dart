import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../core/constants/app_colors.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController(); // Added
  final _passwordController = TextEditingController();

  void _handleSignup() async {
    // Validation: Ensure address isn't empty
    if (_addressController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please provide your address")),
      );
      return;
    }

    final auth = context.read<AuthProvider>();
    final error = await auth.signup(
      name: _nameController.text,
      email: _emailController.text,
      phone: _phoneController.text,
      address: _addressController.text, // Passed address here
      password: _passwordController.text,
    );

    if (error == null && mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("Account created! Please login."),
            backgroundColor: AppColors.success),
      );
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error!), backgroundColor: AppColors.error),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = context.watch<AuthProvider>().isLoading;

    return Scaffold(
      appBar: AppBar(title: const Text("Join LLCET")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(30),
        child: Column(
          children: [
            const Text("Become a Volunteer",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Text("Fill in your details to get started.",
                textAlign: TextAlign.center),
            const SizedBox(height: 40),

            TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                    labelText: "Full Name",
                    prefixIcon: Icon(Icons.person_outline))),
            const SizedBox(height: 15),
            TextField(
                controller: _phoneController,
                decoration: const InputDecoration(
                    labelText: "Mobile Number",
                    prefixIcon: Icon(Icons.phone_android))),
            const SizedBox(height: 15),
            TextField(
                controller: _emailController,
                decoration: const InputDecoration(
                    labelText: "Email Address",
                    prefixIcon: Icon(Icons.email_outlined))),
            const SizedBox(height: 15),

            // --- NEW: Address Field ---
            TextField(
              controller: _addressController,
              maxLines: 3, // Multi-line for address
              decoration: const InputDecoration(
                labelText: "Full Address",
                prefixIcon: Padding(
                  padding: EdgeInsets.only(bottom: 40), // Aligns icon to top
                  child: Icon(Icons.location_on_outlined),
                ),
              ),
            ),
            const SizedBox(height: 15),

            TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                    labelText: "Password",
                    prefixIcon: Icon(Icons.lock_outline))),

            const SizedBox(height: 40),
            isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _handleSignup,
                    child: const Text("CREATE ACCOUNT")),
          ],
        ),
      ),
    );
  }
}
