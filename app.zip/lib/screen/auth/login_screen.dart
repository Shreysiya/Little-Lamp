import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../core/constants/app_colors.dart';
import 'signup_screen.dart';
import 'forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  bool _emailFocused = false;
  bool _passwordFocused = false;

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  // ── G4 Light Design Tokens ──────────────────────────────
  static const Color _bg = Color(0xFFEDE6FF); // unified background
  static const Color _deepPurple = Color(0xFF2D1B4E); // headings
  static const Color _purple = Color(0xFF5B2D8E); // labels, links
  static const Color _midPurple = Color(0xFF6B5A8A); // subtitles (WCAG AA)
  static const Color _orange = Color(0xFFF5840C); // accent dot / shadow
  static const Color _blue = Color(0xFF5BAEE8); // divider lines
  // ────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.12),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );

    Future.delayed(const Duration(milliseconds: 100), () {
      _fadeController.forward();
      _slideController.forward();
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _handleLogin() async {
    HapticFeedback.lightImpact();
    final auth = context.read<AuthProvider>();
    final error = await auth.login(
      _emailController.text.trim(),
      _passwordController.text,
    );
    if (error != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.error_outline_rounded,
                  color: Colors.white, size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text(error,
                    style: const TextStyle(fontWeight: FontWeight.w500)),
              ),
            ],
          ),
          backgroundColor: const Color(0xFFD32F2F),
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = context.watch<AuthProvider>().isLoading;
    final size = MediaQuery.of(context).size;

    // Light status bar icons on light background
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ));

    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // ── UNIFIED FLAT BACKGROUND ──────────────────────
          Container(width: size.width, height: size.height, color: _bg),

          // ── AMBIENT ORB — top right orange ───────────────
          Positioned(
            top: -30,
            right: -40,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    _orange.withOpacity(0.18),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // ── AMBIENT ORB — bottom left blue ───────────────
          Positioned(
            bottom: 100,
            left: -45,
            child: Container(
              width: 190,
              height: 190,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    _blue.withOpacity(0.18),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // ── AMBIENT ORB — centre purple ──────────────────
          Positioned(
            top: size.height * 0.38,
            left: size.width / 2 - 130,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    _purple.withOpacity(0.07),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // ── MAIN SCROLL CONTENT ──────────────────────────
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SlideTransition(
                position: _slideAnim,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    children: [
                      // Logo — full width, no circle, no padding container
                      _buildLogoHero(),
                      // Title + divider + tagline
                      _buildTitleSection(),
                      const SizedBox(height: 20),
                      // Glass form card
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 18),
                        child: _buildFormCard(isLoading),
                      ),
                      const SizedBox(height: 22),
                      _buildSignUpRow(),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── LOGO HERO ─────────────────────────────────────────────────────────────
  // Logo placed full-width with transparent PNG so it merges with bg
  Widget _buildLogoHero() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(43, 48, 43, 0),
      child: Image.asset(
        'assets/logo.png', // use the background-removed transparent PNG
        width: double.infinity,
        fit: BoxFit.contain,
      ),
    );
  }

  // ── TITLE + DIVIDER + TAGLINE ──────────────────────────────────────────────
  Widget _buildTitleSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      child: Column(
        children: [
          Text(
            "LLCET CONNECT",
            style: GoogleFonts.poppins(
              color: _deepPurple,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.5,
            ),
          ),
          const SizedBox(height: 8),
          // Decorative divider — two lines + orange dot
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 30,
                height: 1.5,
                decoration: BoxDecoration(
                  color: _blue.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  color: _orange,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _orange.withOpacity(0.5),
                      blurRadius: 6,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                width: 30,
                height: 1.5,
                decoration: BoxDecoration(
                  color: _blue.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            "Together We Can Make a Difference",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _midPurple, // ✅ WCAG AA 5.03x
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }

  // ── GLASS FORM CARD ────────────────────────────────────────────────────────
  Widget _buildFormCard(bool isLoading) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(26),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.62),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: Colors.white.withOpacity(0.95), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _purple.withOpacity(0.10),
              blurRadius: 32,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Welcome Back 👋",
                style: GoogleFonts.poppins(
                  color: _deepPurple,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                "Access your LLCET account",
                style: TextStyle(
                  color: _midPurple, // ✅ WCAG AA 5.03x
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 22),
              _buildField(
                controller: _emailController,
                label: "EMAIL ADDRESS",
                hint: "you@example.com",
                icon: Icons.mail_outline_rounded,
                isFocused: _emailFocused,
                onFocusChange: (v) => setState(() => _emailFocused = v),
              ),
              const SizedBox(height: 14),
              _buildField(
                controller: _passwordController,
                label: "PASSWORD",
                hint: "Enter your password",
                icon: Icons.lock_outline_rounded,
                isPassword: true,
                obscure: _obscurePassword,
                onToggleObscure: () =>
                    setState(() => _obscurePassword = !_obscurePassword),
                isFocused: _passwordFocused,
                onFocusChange: (v) => setState(() => _passwordFocused = v),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const ForgotPasswordScreen()),
                  ),
                  style: TextButton.styleFrom(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text(
                    "Forgot Password?",
                    style: TextStyle(
                      color: _purple, // ✅ 7.85x
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              isLoading
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        child: CircularProgressIndicator(
                          color: _purple,
                          strokeWidth: 2.5,
                        ),
                      ),
                    )
                  : _buildSignInButton(),
            ],
          ),
        ),
      ),
    );
  }

  // ── INPUT FIELD ────────────────────────────────────────────────────────────
  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool isPassword = false,
    bool? obscure,
    VoidCallback? onToggleObscure,
    required bool isFocused,
    required ValueChanged<bool> onFocusChange,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: _purple, // ✅ 7.85x
            fontSize: 9.5,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.0,
          ),
        ),
        const SizedBox(height: 6),
        Focus(
          onFocusChange: onFocusChange,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              color: isFocused
                  ? _purple.withOpacity(0.05)
                  : Colors.white.withOpacity(0.75),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(
                color: isFocused ? _purple : _purple.withOpacity(0.12),
                width: isFocused ? 1.8 : 1.5,
              ),
            ),
            child: TextField(
              controller: controller,
              obscureText: isPassword ? (obscure ?? true) : false,
              keyboardType: isPassword
                  ? TextInputType.visiblePassword
                  : TextInputType.emailAddress,
              style: const TextStyle(
                fontSize: 13.5,
                color: _deepPurple, // ✅ 12.60x
                fontWeight: FontWeight.w500,
              ),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(
                  color: Color(0xFF8872AA), // ✅ 3.45x on white field
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                ),
                prefixIcon: Padding(
                  padding: const EdgeInsets.only(left: 13, right: 9),
                  child: Icon(
                    icon,
                    color: isFocused ? _purple : _purple.withOpacity(0.35),
                    size: 19,
                  ),
                ),
                prefixIconConstraints:
                    const BoxConstraints(minWidth: 0, minHeight: 0),
                suffixIcon: isPassword
                    ? IconButton(
                        onPressed: onToggleObscure,
                        icon: Icon(
                          obscure ?? true
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined,
                          color: _purple.withOpacity(0.4),
                          size: 19,
                        ),
                      )
                    : null,
                border: InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── SIGN IN BUTTON ─────────────────────────────────────────────────────────
  Widget _buildSignInButton() {
    return GestureDetector(
      onTap: _handleLogin,
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF3B1A6B), Color(0xFF5B2D8E), Color(0xFF7B3FAF)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: _purple.withOpacity(0.40),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "SIGN IN",
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w800,
                letterSpacing: 2.0,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.22),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.arrow_forward_rounded,
                  color: Colors.white, size: 15),
            ),
          ],
        ),
      ),
    );
  }

  // ── NEW MEMBER ROW ─────────────────────────────────────────────────────────
  Widget _buildSignUpRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          "New Member? ",
          style: TextStyle(
            color: _midPurple, // ✅ WCAG AA 5.03x
            fontWeight: FontWeight.w500,
            fontSize: 13,
          ),
        ),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SignupScreen()),
          ),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: _purple.withOpacity(0.10),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _purple.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: const Text(
              "Create Account",
              style: TextStyle(
                color: _purple, // ✅ 7.85x
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
