import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../core/constants/app_colors.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final emailController = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text("Reset Password")),
      body: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          children: [
            const Icon(Icons.lock_reset, size: 80, color: AppColors.primary),
            const SizedBox(height: 20),
            const Text("Enter your email to receive a reset link.",
                textAlign: TextAlign.center),
            const SizedBox(height: 40),
            TextField(
                controller: emailController,
                decoration: const InputDecoration(labelText: "Email")),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                final error = await context
                    .read<AuthProvider>()
                    .resetPassword(emailController.text);
                if (error == null) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text("Link sent! Check your inbox.")));
                  Navigator.pop(context);
                }
              },
              child: const Text("SEND RESET LINK"),
            ),
          ],
        ),
      ),
    );
  }
}
