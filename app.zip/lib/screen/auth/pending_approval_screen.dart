import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../providers/auth_provider.dart';

class PendingApprovalScreen extends StatefulWidget {
  const PendingApprovalScreen({super.key});

  @override
  State<PendingApprovalScreen> createState() => _PendingApprovalScreenState();
}

class _PendingApprovalScreenState extends State<PendingApprovalScreen>
    with TickerProviderStateMixin {

  // ── G4 Light Design Tokens ───────────────────────────────
  static const Color _bg         = Color(0xFFEDE6FF);
  static const Color _deepPurple = Color(0xFF2D1B4E);
  static const Color _purple     = Color(0xFF5B2D8E);
  static const Color _midPurple  = Color(0xFF6B5A8A);
  static const Color _orange     = Color(0xFFF5840C);
  static const Color _blue       = Color(0xFF5BAEE8);
  // ─────────────────────────────────────────────────────────

  late AnimationController _fadeController;
  late AnimationController _pulseController;
  late Animation<double>   _fadeAnim;
  late Animation<double>   _pulseAnim;

  @override
  void initState() {
    super.initState();

    _fadeController  = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);

    _fadeAnim  = CurvedAnimation(parent: _fadeController,  curve: Curves.easeOut);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));

    Future.delayed(const Duration(milliseconds: 100), () => _fadeController.forward());

    // Auto-check approval status every time screen is resumed
    _listenToApprovalStatus();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  // ── REAL-TIME LISTENER — auto-navigates when approved ────
  void _listenToApprovalStatus() {
    final uid = context.read<AuthProvider>().currentUser?.uid;
    if (uid == null) return;

    FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .snapshots()
        .listen((doc) {
      if (!mounted) return;
      if (!doc.exists) return;

      final status = doc.data()?['status'] as String?;

      if (status == 'approved') {
        Navigator.pushReplacementNamed(context, '/member-home');
      } else if (status == 'rejected') {
        Navigator.pushReplacementNamed(context, '/rejected');
      }
    });
  }

  void _handleLogout() async {
    await context.read<AuthProvider>().logout();
    if (mounted) Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    final auth     = context.watch<AuthProvider>();
    final uid      = auth.currentUser?.uid;
    final size     = MediaQuery.of(context).size;

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ));

    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // ── BACKGROUND ──────────────────────────────────
          Container(width: size.width, height: size.height, color: _bg),

          // ── AMBIENT ORB — top right ──────────────────────
          Positioned(
            top: -40, right: -50,
            child: Container(
              width: 220, height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [_orange.withOpacity(0.16), Colors.transparent],
                ),
              ),
            ),
          ),

          // ── AMBIENT ORB — bottom left ────────────────────
          Positioned(
            bottom: 60, left: -50,
            child: Container(
              width: 200, height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [_blue.withOpacity(0.16), Colors.transparent],
                ),
              ),
            ),
          ),

          // ── MAIN CONTENT ────────────────────────────────
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Column(
                children: [
                  // ── TOP BAR ────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                    child: Row(
                      children: [
                        Image.asset('assets/logo.png', height: 36, fit: BoxFit.contain),
                        const Spacer(),
                        TextButton.icon(
                          onPressed: _handleLogout,
                          icon: Icon(Icons.logout_rounded, size: 16, color: _midPurple),
                          label: Text(
                            "Logout",
                            style: TextStyle(
                              color: _midPurple,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // ── STATUS CARD ─────────────────────────
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: _buildStatusCard(uid),
                  ),

                  const SizedBox(height: 32),

                  // ── STEPS CARD ──────────────────────────
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: _buildStepsCard(),
                  ),

                  const Spacer(),

                  // ── FOOTER NOTE ─────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30, 0, 30, 30),
                    child: Text(
                      "This page will automatically update once the admin reviews your application. No need to refresh!",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _midPurple,
                        fontSize: 11,
                        fontWeight: FontWeight.w400,
                        height: 1.6,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── STATUS CARD ───────────────────────────────────────────
  Widget _buildStatusCard(String? uid) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(26),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.62),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: Colors.white.withOpacity(0.95), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _purple.withOpacity(0.10),
              blurRadius: 32,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            children: [
              // Pulsing clock icon
              ScaleTransition(
                scale: _pulseAnim,
                child: Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        _orange.withOpacity(0.15),
                        _purple.withOpacity(0.1),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: _orange.withOpacity(0.3), width: 2),
                  ),
                  child: Icon(
                    Icons.hourglass_top_rounded,
                    color: _orange,
                    size: 36,
                  ),
                ),
              ),

              const SizedBox(height: 20),

              Text(
                "Application Submitted!",
                style: GoogleFonts.poppins(
                  color: _deepPurple,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 8),

              // Divider
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 28, height: 1.5,
                    decoration: BoxDecoration(
                      color: _blue.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      color: _orange,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(color: _orange.withOpacity(0.5), blurRadius: 5),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    width: 28, height: 1.5,
                    decoration: BoxDecoration(
                      color: _blue.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),

              Text(
                "Your membership application is under review by the LLCET admin. You will be notified once approved.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _midPurple,
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                  height: 1.6,
                ),
              ),

              const SizedBox(height: 20),

              // Member name from Firestore
              if (uid != null)
                StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('users')
                      .doc(uid)
                      .snapshots(),
                  builder: (context, snapshot) {
                    final name = snapshot.data?.get('fullName') as String? ?? '';
                    if (name.isEmpty) return const SizedBox.shrink();
                    return Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 10),
                      decoration: BoxDecoration(
                        color: _purple.withOpacity(0.07),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: _purple.withOpacity(0.15), width: 1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.person_outline_rounded,
                              color: _purple, size: 16),
                          const SizedBox(width: 8),
                          Text(
                            name,
                            style: TextStyle(
                              color: _deepPurple,
                              fontSize: 13.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),

              const SizedBox(height: 16),

              // Status badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                decoration: BoxDecoration(
                  color: _orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _orange.withOpacity(0.3), width: 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 7, height: 7,
                      decoration: BoxDecoration(
                        color: _orange,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                              color: _orange.withOpacity(0.6), blurRadius: 4),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "Pending Approval",
                      style: TextStyle(
                        color: _orange,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── WHAT HAPPENS NEXT CARD ────────────────────────────────
  Widget _buildStepsCard() {
    final steps = [
      (Icons.check_circle_outline_rounded, "Application received by LLCET admin"),
      (Icons.manage_accounts_outlined,     "Admin reviews your details"),
      (Icons.verified_outlined,            "You get approved & app unlocks"),
    ];

    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.5),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.9), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _purple.withOpacity(0.07),
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "What happens next?",
                style: GoogleFonts.poppins(
                  color: _deepPurple,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 14),
              ...steps.asMap().entries.map((entry) {
                final i    = entry.key;
                final step = entry.value;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Step number circle
                      Container(
                        width: 24, height: 24,
                        decoration: BoxDecoration(
                          color: _purple.withOpacity(0.12),
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: _purple.withOpacity(0.25), width: 1),
                        ),
                        child: Center(
                          child: Text(
                            "${i + 1}",
                            style: TextStyle(
                              color: _purple,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Icon(step.$1, color: _purple, size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          step.$2,
                          style: TextStyle(
                            color: _midPurple,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w500,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
