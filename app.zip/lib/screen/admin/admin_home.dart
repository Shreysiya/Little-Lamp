// ══════════════════════════════════════════════════════════════
// admin_home.dart
// LLCET Admin Panel · G4 Design · Clean Shell
// Tabs: Dashboard · Members · Payments · Reports · Content
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import 'tabs/dashboard_tab.dart';
import 'tabs/members_tab.dart';
import 'tabs/payments_tab.dart';
import 'tabs/reports_tab.dart';
import 'tabs/content_tab.dart';
import 'utils/g4_theme.dart';
import 'utils/g4_sheet.dart';

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  int _selectedIndex = 0;
  String _selectedFY = '2026-2027';

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ));

    final adminUid = context.read<AuthProvider>().userId ?? '';

    final views = [
      DashboardTab(
        selectedFY: _selectedFY,
        onFYChanged: (fy) => setState(() => _selectedFY = fy),
        onTabTap: (i) => setState(() => _selectedIndex = i),
      ),
      MembersTab(adminUid: adminUid),
      PaymentsTab(selectedFY: _selectedFY),
      ReportsTab(selectedFY: _selectedFY),
      const ContentTab(),
    ];

    return Scaffold(
      backgroundColor: G4.bg,
      body: Column(children: [
        _buildTopBar(context),
        Expanded(child: views[_selectedIndex]),
      ]),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ── Top Bar ───────────────────────────────────────────────
  Widget _buildTopBar(BuildContext context) {
    const titles = [
      'Command Center',
      'Members',
      'Payments',
      'Reports',
      'Content'
    ];
    final auth = context.read<AuthProvider>();

    return Container(
      color: G4.bg,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        left: 20,
        right: 12,
        bottom: 12,
      ),
      child: Row(children: [
        // Logo
        ClipRRect(
          borderRadius: BorderRadius.circular(11),
          child: Image.asset(
            'assets/logo.png',
            width: 36,
            height: 36,
            fit: BoxFit.contain,
          ),
        ),
        const SizedBox(width: 10),
        // Title + greeting
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(titles[_selectedIndex],
                  style: G4.poppins(size: 17, weight: FontWeight.w700)),
              if (_selectedIndex == 0)
                Text(
                  _greeting(),
                  style: G4.poppins(
                      size: 11, color: G4.orange, weight: FontWeight.w500),
                ),
            ],
          ),
        ),
        // Admin avatar → profile sheet
        GestureDetector(
          onTap: () => _showAdminProfile(context, auth),
          child: Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                  colors: [Color(0xFFF5840C), Color(0xFF5B2D8E)]),
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: Center(
              child: Text(
                (auth.userName ?? 'A')[0].toUpperCase(),
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  // ── Bottom Nav ────────────────────────────────────────────
  Widget _buildBottomNav() {
    const items = [
      _NavDef(Icons.dashboard_rounded, Icons.dashboard_outlined, 'Home'),
      _NavDef(Icons.people_alt_rounded, Icons.people_alt_outlined, 'Members'),
      _NavDef(Icons.account_balance_wallet_rounded,
          Icons.account_balance_wallet_outlined, 'Payments'),
      _NavDef(Icons.bar_chart_rounded, Icons.bar_chart_outlined, 'Reports'),
      _NavDef(Icons.campaign_rounded, Icons.campaign_outlined, 'Content'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.85),
        border: Border(top: BorderSide(color: G4.purple.withOpacity(0.1))),
        boxShadow: [
          BoxShadow(
              color: G4.purple.withOpacity(0.08),
              blurRadius: 20,
              offset: const Offset(0, -4))
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: items.asMap().entries.map((e) {
              final active = _selectedIndex == e.key;
              return GestureDetector(
                onTap: () => setState(() => _selectedIndex = e.key),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: active
                        ? G4.purple.withOpacity(0.12)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(active ? e.value.activeIcon : e.value.icon,
                        color: active ? G4.purple : G4.midPurple, size: 22),
                    const SizedBox(height: 3),
                    Text(e.value.label,
                        style: TextStyle(
                          color: active ? G4.purple : G4.midPurple,
                          fontSize: 10,
                          fontWeight:
                              active ? FontWeight.w700 : FontWeight.w400,
                        )),
                  ]),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  // ── Admin Profile Sheet ───────────────────────────────────
  void _showAdminProfile(BuildContext context, AuthProvider auth) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => G4Sheet(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                  colors: [Color(0xFFF5840C), Color(0xFF5B2D8E)]),
            ),
            child: Center(
              child: Text(
                (auth.userName ?? 'A')[0].toUpperCase(),
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.w800),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(auth.userName ?? 'Admin',
              style: G4.poppins(size: 18, weight: FontWeight.w700)),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: G4.purple.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text('Administrator',
                style: G4.poppins(size: 11, color: G4.purple)),
          ),
          const SizedBox(height: 24),
          G4ActionButton(
            label: 'Logout',
            icon: Icons.logout_rounded,
            color: G4.red,
            onTap: () async {
              Navigator.pop(context);
              await auth.logout();
            },
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  // ── Helpers ───────────────────────────────────────────────
  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good Morning, Admin ☀️';
    if (h < 17) return 'Good Afternoon, Admin 🌤️';
    return 'Good Evening, Admin 🌙';
  }
}

// ── Nav Item Model ────────────────────────────────────────────
class _NavDef {
  final IconData activeIcon, icon;
  final String label;
  const _NavDef(this.activeIcon, this.icon, this.label);
}
