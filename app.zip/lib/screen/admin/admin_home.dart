import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../providers/auth_provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/trust_details.dart';

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  int _selectedIndex = 0;
  String selectedFY = "2026-2027";

  @override
  Widget build(BuildContext context) {
    final List<Widget> views = [
      _buildPremiumDashboard(),
      const VolunteerManagementHub(),
      const PaymentVerificationHub(),
      ReportsHub(selectedFY: selectedFY),
      const ContentManagementHub(),
    ];

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: Text(_getAppBarTitle(),
            style: const TextStyle(
                fontWeight: FontWeight.bold, color: Colors.white)),
        flexibleSpace: Container(
            decoration:
                const BoxDecoration(gradient: AppColors.primaryGradient)),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: () => context.read<AuthProvider>().logout(),
          )
        ],
      ),
      body: views[_selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) =>
            setState(() => _selectedIndex = index),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.dashboard_outlined), label: 'Home'),
          NavigationDestination(
              icon: Icon(Icons.people_alt_outlined), label: 'Users'),
          NavigationDestination(
              icon: Icon(Icons.fact_check_outlined), label: 'Verify'),
          NavigationDestination(
              icon: Icon(Icons.assessment_outlined), label: 'Reports'),
          NavigationDestination(
              icon: Icon(Icons.poll_outlined), label: 'Polls'),
        ],
      ),
    );
  }

  String _getAppBarTitle() {
    switch (_selectedIndex) {
      case 0:
        return "LLCET Command Center";
      case 1:
        return "Volunteer Directory";
      case 2:
        return "Verify Payments";
      case 3:
        return "Reports & Alerts";
      default:
        return "POLLS & News";
    }
  }

  // --- 1. PREMIUM DASHBOARD ---
  Widget _buildPremiumDashboard() {
    return StreamBuilder(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (context, AsyncSnapshot<QuerySnapshot> userSnap) {
        return StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('contributions')
              .where('academicYear', isEqualTo: selectedFY)
              .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> paySnap) {
            if (!userSnap.hasData || !paySnap.hasData)
              return const Center(child: CircularProgressIndicator());

            final totalApproved = userSnap.data!.docs
                .where((d) => d['status'] == 'approved')
                .length;
            final pendingVerify = paySnap.data!.docs
                .where((d) => d['status'] == 'Awaiting Approval')
                .length;
            final totalAmount = paySnap.data!.docs
                .where((d) => d['status'] == 'Paid')
                .fold(0.0, (sum, doc) => sum + (doc['amount'] as num));

            return SingleChildScrollView(
              child: Column(
                children: [
                  _buildFYScroller(),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.4,
                      children: [
                        _metricCard("Total Collected", "₹$totalAmount",
                            Icons.account_balance_wallet, Colors.blue, () {}),
                        _metricCard(
                            "Active Members",
                            "$totalApproved",
                            Icons.group,
                            Colors.green,
                            () => setState(() => _selectedIndex = 1)),
                        _metricCard(
                            "Pending Verify",
                            "$pendingVerify",
                            Icons.pending_actions,
                            Colors.orange,
                            () => setState(() => _selectedIndex = 2)),
                        _metricCard(
                            "Reports Hub",
                            "Go",
                            Icons.assessment,
                            Colors.purple,
                            () => setState(() => _selectedIndex = 3)),
                      ],
                    ),
                  ),
                  _buildMonthlyList(paySnap.data!.docs, totalAmount),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildFYScroller() {
    final fYears = ["2024-2025", "2025-2026", "2026-2027", "2027-2028"];
    return Container(
      height: 55,
      margin: const EdgeInsets.only(top: 10),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: fYears.length,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemBuilder: (context, i) {
          bool isSel = selectedFY == fYears[i];
          return GestureDetector(
            onTap: () => setState(() => selectedFY = fYears[i]),
            child: Container(
              margin: const EdgeInsets.only(right: 10),
              padding: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                  color: isSel ? Colors.blue.shade800 : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color:
                          isSel ? Colors.blue.shade800 : Colors.grey.shade300)),
              alignment: Alignment.center,
              child: Text(fYears[i],
                  style: TextStyle(
                      color: isSel ? Colors.white : Colors.black87,
                      fontWeight: FontWeight.bold)),
            ),
          );
        },
      ),
    );
  }

  Widget _buildMonthlyList(
      List<QueryDocumentSnapshot> docs, double grandTotal) {
    final months = [
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "January",
      "February",
      "March"
    ];
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: Colors.grey.shade100)),
      child: Column(
        children: [
          ...months.asMap().entries.map((entry) {
            double mTotal = docs
                .where((d) =>
                    d['fiscalIndex'] == entry.key && d['status'] == 'Paid')
                .fold(0.0, (sum, doc) => sum + (doc['amount'] as num));
            return Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(entry.value),
                      Text("₹$mTotal",
                          style: const TextStyle(fontWeight: FontWeight.bold))
                    ]));
          }).toList(),
          const Divider(thickness: 2),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text("GRAND TOTAL",
                style:
                    TextStyle(fontWeight: FontWeight.bold, color: Colors.blue)),
            Text("₹$grandTotal",
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Colors.blue))
          ]),
        ],
      ),
    );
  }

  Widget _metricCard(
      String title, String val, IconData icon, Color color, VoidCallback tap) {
    return InkWell(
        onTap: tap,
        child: Container(
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.grey.shade100)),
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 8),
              Text(val,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold)),
              Text(title,
                  style: const TextStyle(fontSize: 10, color: Colors.grey))
            ])));
  }
}

// --- 2. VOLUNTEER HUB ---
class VolunteerManagementHub extends StatefulWidget {
  const VolunteerManagementHub({super.key});
  @override
  State<VolunteerManagementHub> createState() => _VolunteerManagementHubState();
}

class _VolunteerManagementHubState extends State<VolunteerManagementHub> {
  String searchQuery = "";
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: const TabBar(
            tabs: [Tab(text: "New Users"), Tab(text: "Approved Directory")]),
        body: TabBarView(
            children: [_buildUserList('pending'), _buildUserList('approved')]),
      ),
    );
  }

  Widget _buildUserList(String status) {
    return Column(
      children: [
        if (status == 'approved')
          Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                  decoration: const InputDecoration(
                      hintText: "Search name...",
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder()),
                  onChanged: (v) =>
                      setState(() => searchQuery = v.toLowerCase()))),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .where('status', isEqualTo: status)
                .snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return const LinearProgressIndicator();
              final docs = snap.data!.docs
                  .where((d) =>
                      d['name'].toString().toLowerCase().contains(searchQuery))
                  .toList();
              return ListView.builder(
                itemCount: docs.length,
                itemBuilder: (context, i) => ListTile(
                  title: Text(docs[i]['name']),
                  subtitle: Text(docs[i]['phone']),
                  trailing: status == 'pending'
                      ? ElevatedButton(
                          onPressed: () => _update(docs[i].id),
                          child: const Text("APPROVE"))
                      : const Icon(Icons.chevron_right),
                  onTap: () => _showDetail(context, docs[i]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void _update(String id) => FirebaseFirestore.instance
      .collection('users')
      .doc(id)
      .update({'status': 'approved'});

  void _showDetail(BuildContext context, DocumentSnapshot user) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
              title: Text(user['name']),
              content:
                  Text("Phone: ${user['phone']}\nAddress: ${user['address']}"),
              actions: [
                TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _manualPay(context, user.id, user['name']);
                    },
                    child: const Text("MANUAL PAY")),
                TextButton(
                    onPressed: () {
                      FirebaseFirestore.instance
                          .collection('users')
                          .doc(user.id)
                          .delete();
                      Navigator.pop(context);
                    },
                    child: const Text("DELETE",
                        style: TextStyle(color: Colors.red))),
              ],
            ));
  }

  void _manualPay(BuildContext context, String uid, String name) {
    final months = [
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "January",
      "February",
      "March"
    ];
    int selIdx = 0;
    final amtController = TextEditingController(text: "500");
    showDialog(
        context: context,
        builder: (context) => StatefulBuilder(
            builder: (context, setS) => AlertDialog(
                  title: Text("Manual Entry: $name"),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                          controller: amtController,
                          decoration: const InputDecoration(
                              labelText: "Amount Paid (₹)"),
                          keyboardType: TextInputType.number),
                      const SizedBox(height: 15),
                      DropdownButtonFormField<int>(
                        value: selIdx,
                        items: months
                            .asMap()
                            .entries
                            .map((e) => DropdownMenuItem(
                                value: e.key, child: Text(e.value)))
                            .toList(),
                        onChanged: (v) => setS(() => selIdx = v!),
                      ),
                    ],
                  ),
                  actions: [
                    ElevatedButton(
                        onPressed: () {
                          FirebaseFirestore.instance
                              .collection('contributions')
                              .add({
                            'volunteerId': uid,
                            'amount':
                                double.tryParse(amtController.text) ?? 500.0,
                            'fiscalIndex': selIdx,
                            'month': months[selIdx],
                            'status': 'Paid',
                            'transactionId': 'MANUAL_CASH',
                            'academicYear': '2026-2027',
                            'submittedAt': FieldValue.serverTimestamp()
                          });
                          Navigator.pop(context);
                        },
                        child: const Text("SAVE"))
                  ],
                )));
  }
}

// --- 3. VERIFY PAYMENTS ---
class PaymentVerificationHub extends StatelessWidget {
  const PaymentVerificationHub({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('contributions')
          .where('status', isEqualTo: 'Awaiting Approval')
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());
        if (snapshot.data!.docs.isEmpty)
          return const Center(child: Text("No payments to verify."));
        return ListView.builder(
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            var data = snapshot.data!.docs[index];
            return Card(
              margin: const EdgeInsets.all(10),
              child: ListTile(
                title: Text("${data['month']} - ₹${data['amount']}"),
                subtitle: Text("ID: ${data['transactionId']}"),
                trailing: ElevatedButton(
                    onPressed: () => FirebaseFirestore.instance
                        .collection('contributions')
                        .doc(data.id)
                        .update({'status': 'Paid'}),
                    child: const Text("APPROVE")),
              ),
            );
          },
        );
      },
    );
  }
}

// --- 4. REPORTS HUB (PDF Generation Implemented) ---
class ReportsHub extends StatelessWidget {
  final String selectedFY;
  const ReportsHub({super.key, required this.selectedFY});

  Future<void> _genIncomePDF(List<QueryDocumentSnapshot> docs) async {
    final pdf = pw.Document();
    final months = [
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "January",
      "February",
      "March"
    ];
    double grandTotal = 0;

    pdf.addPage(pw.Page(
      build: (pw.Context context) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text("LLCET TRUST - INCOME REPORT ($selectedFY)",
              style:
                  pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 18)),
          pw.SizedBox(height: 20),
          pw.Table.fromTextArray(
            headers: ["Month", "Collection"],
            data: months.asMap().entries.map((e) {
              double mTotal = docs
                  .where(
                      (d) => d['fiscalIndex'] == e.key && d['status'] == 'Paid')
                  .fold(0.0, (s, d) => s + (d['amount'] as num));
              grandTotal += mTotal;
              return [e.value, "Rs. ${mTotal.toStringAsFixed(2)}"];
            }).toList(),
          ),
          pw.SizedBox(height: 20),
          pw.Divider(),
          pw.Align(
              alignment: pw.Alignment.centerRight,
              child: pw.Text(
                  "Grand Total: Rs. ${grandTotal.toStringAsFixed(2)}",
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
        ],
      ),
    ));
    await Printing.sharePdf(
        bytes: await pdf.save(), filename: 'Income_$selectedFY.pdf');
  }

  Future<void> _genDefaultersPDF(List<QueryDocumentSnapshot> users,
      List<QueryDocumentSnapshot> payments) async {
    final pdf = pw.Document();
    int currentMonthIdx = (DateTime.now().month >= 4)
        ? (DateTime.now().month - 4)
        : (DateTime.now().month + 8);

    pdf.addPage(pw.MultiPage(
      build: (pw.Context context) => [
        pw.Text("LLCET TRUST - DEFAULTERS MASTER LIST",
            style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 18)),
        pw.SizedBox(height: 20),
        pw.Table.fromTextArray(
          headers: ["Name", "Phone", "Months Paid", "Status"],
          data: users
              .map((u) {
                int paidCount = payments
                    .where((p) =>
                        p['volunteerId'] == u.id && p['status'] == 'Paid')
                    .length;
                int missed = (currentMonthIdx + 1) - paidCount;
                if (missed <= 0) return null;
                return [
                  u['name'],
                  u['phone'],
                  "$paidCount/12",
                  missed >= 3 ? "ALERT (3+ Missed)" : "Pending"
                ];
              })
              .whereType<List<String>>()
              .toList(),
        ),
      ],
    ));
    await Printing.sharePdf(
        bytes: await pdf.save(), filename: 'Defaulters_$selectedFY.pdf');
  }

  void _showLedgerSearch(BuildContext context,
      List<QueryDocumentSnapshot> users, List<QueryDocumentSnapshot> payments) {
    String search = "";
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setS) => AlertDialog(
          title: const Text("Select Member for Ledger"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                  decoration: const InputDecoration(hintText: "Enter name..."),
                  onChanged: (v) => setS(() => search = v.toLowerCase())),
              SizedBox(
                height: 250,
                width: double.maxFinite,
                child: ListView(
                  children: users
                      .where((u) =>
                          u['name'].toString().toLowerCase().contains(search))
                      .map((u) => ListTile(
                            title: Text(u['name']),
                            onTap: () {
                              Navigator.pop(context);
                              _genMemberLedger(u, payments);
                            },
                          ))
                      .toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _genMemberLedger(
      DocumentSnapshot user, List<QueryDocumentSnapshot> payments) async {
    final pdf = pw.Document();
    final userPayments = payments
        .where((p) => p['volunteerId'] == user.id && p['status'] == 'Paid')
        .toList();
    pdf.addPage(pw.Page(
      build: (pw.Context context) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text("MEMBER PAYMENT LEDGER",
              style:
                  pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 18)),
          pw.Text("Member: ${user['name']}"),
          pw.Text("Phone: ${user['phone']}"),
          pw.SizedBox(height: 20),
          pw.Table.fromTextArray(
            headers: ["Month", "Amount", "Trans ID", "Status"],
            data: userPayments
                .map((p) => [
                      p['month'],
                      "Rs. ${p['amount']}",
                      p['transactionId'],
                      p['status']
                    ])
                .toList(),
          ),
        ],
      ),
    ));
    await Printing.sharePdf(
        bytes: await pdf.save(), filename: 'Ledger_${user['name']}.pdf');
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .where('status', isEqualTo: 'approved')
          .snapshots(),
      builder: (context, userSnap) {
        return StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('contributions')
              .where('academicYear', isEqualTo: selectedFY)
              .snapshots(),
          builder: (context, paySnap) {
            if (!userSnap.hasData || !paySnap.hasData)
              return const Center(child: CircularProgressIndicator());

            final activeVolunteers = userSnap.data!.docs.length;
            int currentMonthIdx = (DateTime.now().month >= 4)
                ? (DateTime.now().month - 4)
                : (DateTime.now().month + 8);

            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  color: Colors.teal.shade700,
                  child: ListTile(
                    leading: const Icon(Icons.people_alt, color: Colors.white),
                    title: const Text("Total Active Volunteers",
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold)),
                    trailing: Text("$activeVolunteers",
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(height: 20),
                const Text("Select Report Type",
                    style: TextStyle(fontWeight: FontWeight.bold)),

                _reportRow(
                    context,
                    "Monthly Income Report",
                    Icons.calendar_month,
                    () => _genIncomePDF(paySnap.data!.docs)),
                _reportRow(
                    context,
                    "Defaulters Master List",
                    Icons.person_off,
                    () => _genDefaultersPDF(
                        userSnap.data!.docs, paySnap.data!.docs)),
                _reportRow(
                    context,
                    "Member Payment Ledger",
                    Icons.menu_book,
                    () => _showLedgerSearch(
                        context, userSnap.data!.docs, paySnap.data!.docs)),
                _reportRow(
                    context,
                    "Annual Financial Summary",
                    Icons.summarize,
                    () => _genIncomePDF(
                        paySnap.data!.docs)), // Same logic for now
                _reportRow(context, "Event Participation Report",
                    Icons.how_to_vote, () {}),

                const Divider(height: 40),
                const Text("🚨 Priority Red Alerts (3+ Missed)",
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.red)),
                ...userSnap.data!.docs.map((user) {
                  int paidCount = paySnap.data!.docs
                      .where((p) =>
                          p['volunteerId'] == user.id && p['status'] == 'Paid')
                      .length;
                  int missedCount = (currentMonthIdx + 1) - paidCount;
                  if (missedCount >= 3) {
                    return Card(
                      color: Colors.red.shade50,
                      child: ListTile(
                        leading: const Icon(Icons.notification_important,
                            color: Colors.red),
                        title: Text(user['name'],
                            style:
                                const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text("Missed: $missedCount months"),
                      ),
                    );
                  }
                  return const SizedBox();
                }).toList(),
              ],
            );
          },
        );
      },
    );
  }

  Widget _reportRow(
      BuildContext context, String title, IconData icon, VoidCallback pdf) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: Colors.blue),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
        trailing: IconButton(
            icon: const Icon(Icons.picture_as_pdf, color: Colors.red, size: 22),
            onPressed: pdf),
      ),
    );
  }
}

// --- 5. POLLS ---
class ContentManagementHub extends StatelessWidget {
  const ContentManagementHub({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
          onPressed: () => _create(context), child: const Icon(Icons.add)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _header("ACTIVE POLLS"),
          _buildPolls(),
          const SizedBox(height: 20),
          _header("NEWS & EVENTS"),
          _buildStream("announcements"),
          _buildStream("events"),
        ],
      ),
    );
  }

  Widget _header(String t) => Padding(
      padding: const EdgeInsets.all(8.0),
      child: Text(t,
          style: const TextStyle(
              fontWeight: FontWeight.bold, color: Colors.blueGrey)));

  Widget _buildStream(String coll) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection(coll).snapshots(),
      builder: (context, snap) => snap.hasData
          ? Column(
              children: snap.data!.docs
                  .map((d) => ListTile(
                      title: Text(d['title'] ?? ''),
                      trailing: IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () => d.reference.delete())))
                  .toList())
          : const SizedBox(),
    );
  }

  Widget _buildPolls() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('polls').snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox();
        return Column(
          children: snap.data!.docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>? ?? {};
            final options = List<String>.from(data['options'] ?? []);
            final votes = data['votes'] as Map? ?? {};
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(data['question'] ?? 'No Question',
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold)),
                          IconButton(
                              icon: const Icon(Icons.delete, size: 18),
                              onPressed: () => doc.reference.delete())
                        ]),
                    ...options.map((opt) {
                      int count = votes.values.where((v) => v == opt).length;
                      double progress =
                          votes.isEmpty ? 0 : count / votes.length;
                      return Column(children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(opt, style: const TextStyle(fontSize: 12)),
                              Text("$count votes")
                            ]),
                        const SizedBox(height: 4),
                        LinearProgressIndicator(
                            value: progress,
                            color: Colors.green,
                            backgroundColor: Colors.grey.shade100),
                        const SizedBox(height: 8)
                      ]);
                    }).toList(),
                  ],
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }

  void _create(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (context) => Wrap(children: [
              ListTile(
                  title: const Text("Announcement"),
                  onTap: () => _add(context, 'announcements')),
              ListTile(
                  title: const Text("Event"),
                  onTap: () => _add(context, 'events')),
              ListTile(
                  title: const Text("Poll"), onTap: () => _addPoll(context)),
            ]));
  }

  void _add(BuildContext context, String coll) {
    Navigator.pop(context);
    final c = TextEditingController();
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
                title: Text("New $coll"),
                content: TextField(controller: c),
                actions: [
                  ElevatedButton(
                      onPressed: () {
                        FirebaseFirestore.instance.collection(coll).add(
                            {'title': c.text, 'createdAt': Timestamp.now()});
                        Navigator.pop(context);
                      },
                      child: const Text("POST"))
                ]));
  }

  void _addPoll(BuildContext context) {
    Navigator.pop(context);
    final qC = TextEditingController();
    List<TextEditingController> opts = [
      TextEditingController(text: "Yes"),
      TextEditingController(text: "No")
    ];
    showDialog(
        context: context,
        builder: (context) => StatefulBuilder(
            builder: (context, setS) => AlertDialog(
                  title: const Text("New Poll"),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextField(
                        controller: qC,
                        decoration:
                            const InputDecoration(labelText: "Question")),
                    ...opts.asMap().entries.map((e) => TextField(
                        controller: e.value,
                        decoration:
                            InputDecoration(labelText: "Option ${e.key + 1}"))),
                    TextButton(
                        onPressed: () =>
                            setS(() => opts.add(TextEditingController())),
                        child: const Text("Add Option"))
                  ])),
                  actions: [
                    ElevatedButton(
                        onPressed: () {
                          FirebaseFirestore.instance.collection('polls').add({
                            'question': qC.text,
                            'options': opts.map((e) => e.text).toList(),
                            'votes': {},
                            'createdAt': Timestamp.now()
                          });
                          Navigator.pop(context);
                        },
                        child: const Text("CREATE"))
                  ],
                )));
  }
}
