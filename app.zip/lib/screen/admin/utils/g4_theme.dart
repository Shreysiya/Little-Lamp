// ══════════════════════════════════════════════════════════════
// utils/g4_theme.dart
// Shared G4 design tokens — import everywhere
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class G4 {
  static const bg = Color(0xFFEDE6FF);
  static const deepPurple = Color(0xFF2D1B4E);
  static const purple = Color(0xFF5B2D8E);
  static const midPurple = Color(0xFF6B5A8A);
  static const orange = Color(0xFFF5840C);
  static const blue = Color(0xFF5BAEE8);
  static const green = Color(0xFF2E7D52);
  static const red = Color(0xFFB00020);

  static BoxDecoration glassCard({Color? shadow}) => BoxDecoration(
        color: Colors.white.withOpacity(0.62),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.9), width: 1.5),
        boxShadow: [
          BoxShadow(
              color: (shadow ?? purple).withOpacity(0.09),
              blurRadius: 16,
              offset: const Offset(0, 4))
        ],
      );

  static TextStyle poppins({
    double size = 14,
    FontWeight weight = FontWeight.w600,
    Color? color,
  }) =>
      GoogleFonts.poppins(
          fontSize: size, fontWeight: weight, color: color ?? deepPurple);
}

// ── Reusable Action Button ─────────────────────────────────
class G4ActionButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const G4ActionButton({
    super.key,
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 48,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            color.withRed((color.red - 30).clamp(0, 255)),
            color,
            color.withBlue((color.blue + 20).clamp(0, 255))
          ], begin: Alignment.centerLeft, end: Alignment.centerRight),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(0.35),
                blurRadius: 12,
                offset: const Offset(0, 4))
          ],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: Colors.white, size: 18),
          const SizedBox(width: 8),
          Text(label,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 14)),
        ]),
      ),
    );
  }
}
