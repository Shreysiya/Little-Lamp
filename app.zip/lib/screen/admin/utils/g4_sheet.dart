// ══════════════════════════════════════════════════════════════
// utils/g4_sheet.dart
// Shared bottom sheet wrapper — use across all tabs
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'g4_theme.dart';

class G4Sheet extends StatelessWidget {
  final Widget child;
  const G4Sheet({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // Handle
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 18),
              decoration: BoxDecoration(
                color: G4.purple.withOpacity(0.18),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            child,
          ]),
        ),
      ),
    );
  }
}
