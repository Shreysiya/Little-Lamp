// ══════════════════════════════════════════════════════════════
// members_tab.dart
// Tab 2 — Members  (Carousel + Pending Requests + Directory)
// LLCET Admin Panel · G4 Design
// ══════════════════════════════════════════════════════════════

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_fonts/google_fonts.dart';

// ── G4 Design Tokens (local copy so this file is self-contained) ──
class _G4 {
  static const bg = Color(0xFFEDE6FF);
  static const deepPurple = Color(0xFF2D1B4E);
  static const purple = Color(0xFF5B2D8E);
  static const midPurple = Color(0xFF6B5A8A);
  static const orange = Color(0xFFF5840C);
  static const blue = Color(0xFF5BAEE8);
  static const green = Color(0xFF2E7D52);
  static const red = Color(0xFFB00020);

  static BoxDecoration glassCard({Color? shadow}) => BoxDecoration(
        color: Colors.white.withOpacity(0.62),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.9), width: 1.5),
        boxShadow: [
          BoxShadow(
              color: (shadow ?? purple).withOpacity(0.09),
              blurRadius: 16,
              offset: const Offset(0, 4))
        ],
      );

  static TextStyle poppins(
          {double size = 14,
          FontWeight weight = FontWeight.w600,
          Color? color}) =>
      GoogleFonts.poppins(
          fontSize: size, fontWeight: weight, color: color ?? deepPurple);
}

// ── Shared Bottom Sheet wrapper ───────────────────────────────
class _G4Sheet extends StatelessWidget {
  final Widget child;
  const _G4Sheet({required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFFEDE6FF),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
                color: const Color(0xFF5B2D8E).withOpacity(0.2),
                borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 20),
        child,
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// MembersTab
// ══════════════════════════════════════════════════════════════
class MembersTab extends StatefulWidget {
  final String adminUid;
  const MembersTab({super.key, required this.adminUid});
  @override
  State<MembersTab> createState() => _MembersTabState();
}

class _MembersTabState extends State<MembersTab>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  final PageController _carouselCtrl = PageController(viewportFraction: 0.88);
  Timer? _carouselTimer;
  int _carouselIdx = 0;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _carouselTimer = Timer.periodic(const Duration(milliseconds: 3500), (_) {
      if (!mounted || !_carouselCtrl.hasClients) return;
      final next = (_carouselIdx + 1) % 3;
      _carouselCtrl.animateToPage(next,
          duration: const Duration(milliseconds: 520),
          curve: Curves.easeInOutCubic);
    });
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _carouselTimer?.cancel();
    _carouselCtrl.dispose();
    super.dispose();
  }

  // ── AUTO FY HELPER ────────────────────────────────────────
  String get _currentFY {
    final now = DateTime.now();
    final start = now.month >= 4 ? now.year : now.year - 1;
    return '$start-${start + 1}';
  }

  // ── AUTO FISCAL MONTH INDEX ───────────────────────────────
  int get _currentMonthIdx {
    final m = DateTime.now().month;
    return m >= 4 ? m - 4 : m + 8;
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      _buildCarousel(),
      const SizedBox(height: 4),
      Container(
        color: Colors.white.withOpacity(0.5),
        child: TabBar(
          controller: _tabCtrl,
          labelColor: _G4.purple,
          unselectedLabelColor: _G4.midPurple,
          indicatorColor: _G4.purple,
          indicatorWeight: 2.5,
          labelStyle:
              const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          unselectedLabelStyle:
              const TextStyle(fontWeight: FontWeight.w500, fontSize: 13),
          tabs: const [
            Tab(text: 'Pending Requests'),
            Tab(text: 'Members Directory'),
          ],
        ),
      ),
      Expanded(
        child: TabBarView(controller: _tabCtrl, children: [
          _buildPendingList(),
          _buildDirectoryList(),
        ]),
      ),
    ]);
  }

  // ══════════════════════════════════════════════════════════
  // MEMBERS CAROUSEL  ✅ FIX: all = approved count only
  // ══════════════════════════════════════════════════════════
  Widget _buildCarousel() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (_, snap) {
        // ✅ FIXED: was snap.data!.docs.length (counted pending too)
        final approved = !snap.hasData
            ? 0
            : snap.data!.docs
                .where((d) => (d.data() as Map)['status'] == 'approved')
                .length;
        final pending = !snap.hasData
            ? 0
            : snap.data!.docs
                .where((d) => (d.data() as Map)['status'] == 'pending')
                .length;
        final all = approved; // Total Members = approved members only

        final slides = [
          _MemberSlide('Total Members', '$all', '👥',
              [const Color(0xFF3B1A6B), _G4.purple]),
          _MemberSlide('Active Members', '$approved', '✅',
              [const Color(0xFF1B4332), _G4.green]),
          _MemberSlide('Pending Approval', '$pending', '⏳',
              [const Color(0xFF7B3000), _G4.orange]),
        ];

        return Column(children: [
          SizedBox(
            height: 120,
            child: PageView.builder(
              controller: _carouselCtrl,
              itemCount: slides.length,
              onPageChanged: (i) => setState(() => _carouselIdx = i),
              itemBuilder: (_, i) {
                final s = slides[i];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: LinearGradient(
                        colors: s.colors,
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight),
                    boxShadow: [
                      BoxShadow(
                          color: s.colors[1].withOpacity(0.35),
                          blurRadius: 14,
                          offset: const Offset(0, 5))
                    ],
                  ),
                  child: Stack(children: [
                    Positioned(
                        top: -20,
                        right: -20,
                        child: Text(s.emoji,
                            style: TextStyle(
                                fontSize: 70,
                                color: Colors.white.withOpacity(0.1)))),
                    Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(s.label,
                                style: TextStyle(
                                    color: Colors.white.withOpacity(0.65),
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600)),
                            const SizedBox(height: 6),
                            Text(s.value,
                                style: _G4.poppins(
                                    size: 32,
                                    weight: FontWeight.w900,
                                    color: Colors.white)),
                          ]),
                    ),
                  ]),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
                3,
                (i) => AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: _carouselIdx == i ? 18 : 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: _carouselIdx == i
                            ? _G4.purple
                            : _G4.purple.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    )),
          ),
        ]);
      },
    );
  }

  // ══════════════════════════════════════════════════════════
  // PENDING REQUESTS
  // ══════════════════════════════════════════════════════════
  Widget _buildPendingList() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .where('status', isEqualTo: 'pending')
          .snapshots(),
      builder: (context, snap) {
        if (!snap.hasData)
          return const Center(
              child: CircularProgressIndicator(color: _G4.purple));
        if (snap.data!.docs.isEmpty)
          return _emptyState(Icons.check_circle_outline_rounded,
              'No Pending Requests', 'All caught up! ✅');
        return ListView.builder(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          itemCount: snap.data!.docs.length,
          itemBuilder: (context, i) =>
              _pendingCard(context, snap.data!.docs[i]),
        );
      },
    );
  }

  Widget _pendingCard(BuildContext context, DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final name = data['name'] ?? 'Unknown';
    final phone = data['phone'] ?? '';
    final email = data['email'] ?? '';
    final address = data['address'] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: _G4.glassCard(),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(
                radius: 22,
                backgroundColor: _G4.purple.withOpacity(0.12),
                child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: const TextStyle(
                        color: _G4.purple,
                        fontWeight: FontWeight.w800,
                        fontSize: 16))),
            const SizedBox(width: 12),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(name,
                      style: _G4.poppins(size: 14, weight: FontWeight.w700)),
                  Text(email,
                      style: _G4.poppins(size: 11, color: _G4.midPurple)),
                ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(
                color: _G4.orange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _G4.orange.withOpacity(0.3)),
              ),
              child: Text('Pending',
                  style: TextStyle(
                      color: _G4.orange,
                      fontSize: 10,
                      fontWeight: FontWeight.w700)),
            ),
          ]),
          const SizedBox(height: 10),
          GestureDetector(
            onTap: () => _launch('tel:$phone'),
            child: _infoRow(Icons.phone_android_rounded, phone, tappable: true),
          ),
          const SizedBox(height: 4),
          GestureDetector(
            onTap: () => _launch(
                'https://maps.google.com/?q=${Uri.encodeComponent(address)}'),
            child:
                _infoRow(Icons.location_on_outlined, address, tappable: true),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(
                child: _actionBtn('REJECT', _G4.red,
                    outlined: true,
                    onTap: () =>
                        _confirmAction(context, doc.id, 'rejected', name))),
            const SizedBox(width: 10),
            Expanded(
                flex: 2,
                child: _actionBtn('APPROVE', _G4.green,
                    onTap: () =>
                        _confirmAction(context, doc.id, 'approved', name))),
          ]),
        ]),
      ),
    );
  }

  void _confirmAction(
      BuildContext context, String docId, String status, String name) {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text(
                  status == 'approved'
                      ? 'Approve Member'
                      : 'Reject Application',
                  style: _G4.poppins(size: 15, weight: FontWeight.w700)),
              content: Text(
                  status == 'approved'
                      ? 'Approve $name as an LLCET member?'
                      : "Reject $name's application?",
                  style: _G4.poppins(size: 13, color: _G4.midPurple)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor:
                          status == 'approved' ? _G4.green : _G4.red,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  onPressed: () async {
                    Navigator.pop(context);
                    await FirebaseFirestore.instance
                        .collection('users')
                        .doc(docId)
                        .update({
                      'status': status,
                      if (status == 'approved') ...{
                        'approvedAt': FieldValue.serverTimestamp(),
                        'approvedBy': widget.adminUid,
                      },
                    });
                  },
                  child: Text(status == 'approved' ? 'Approve' : 'Reject',
                      style: const TextStyle(color: Colors.white)),
                ),
              ],
            ));
  }

  // ══════════════════════════════════════════════════════════
  // MEMBERS DIRECTORY
  // ══════════════════════════════════════════════════════════
  Widget _buildDirectoryList() {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.75),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _G4.purple.withOpacity(0.12), width: 1.5),
          ),
          child: TextField(
            onChanged: (v) => setState(() => _searchQuery = v.toLowerCase()),
            style: _G4.poppins(size: 13),
            decoration: InputDecoration(
              hintText: 'Search member...',
              hintStyle: TextStyle(color: _G4.midPurple, fontSize: 13),
              prefixIcon: Icon(Icons.search_rounded,
                  color: _G4.purple.withOpacity(0.5), size: 20),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 13),
            ),
          ),
        ),
      ),
      Expanded(
        child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('users')
              .where('status', isEqualTo: 'approved')
              .snapshots(),
          builder: (context, snap) {
            if (!snap.hasData)
              return const Center(
                  child: CircularProgressIndicator(color: _G4.purple));
            final docs = snap.data!.docs.where((d) {
              final n =
                  ((d.data() as Map)['name'] ?? '').toString().toLowerCase();
              return n.contains(_searchQuery);
            }).toList();
            if (docs.isEmpty)
              return _emptyState(Icons.people_outline, 'No Members Found',
                  'Try a different search');
            return ListView.builder(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 16),
              itemCount: docs.length,
              itemBuilder: (context, i) => _memberCard(context, docs[i]),
            );
          },
        ),
      ),
    ]);
  }

  Widget _memberCard(BuildContext context, DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final name = data['name'] ?? 'Unknown';
    final phone = data['phone'] ?? '';
    return GestureDetector(
      onTap: () => _showMemberDetail(context, doc),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: _G4.glassCard(),
        child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: CircleAvatar(
            radius: 22,
            backgroundColor: _G4.purple.withOpacity(0.12),
            child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                style: const TextStyle(
                    color: _G4.purple,
                    fontWeight: FontWeight.w700,
                    fontSize: 15)),
          ),
          title: Text(name,
              style: _G4.poppins(size: 13.5, weight: FontWeight.w600)),
          subtitle:
              Text(phone, style: _G4.poppins(size: 11.5, color: _G4.midPurple)),
          trailing: Icon(Icons.chevron_right_rounded, color: _G4.midPurple),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // MEMBER DETAIL SHEET
  // ══════════════════════════════════════════════════════════
  void _showMemberDetail(BuildContext context, DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final name = data['name'] ?? 'Unknown';
    final phone = data['phone'] ?? '';
    final email = data['email'] ?? '';
    final address = data['address'] ?? '';

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _G4Sheet(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          CircleAvatar(
              radius: 32,
              backgroundColor: _G4.purple.withOpacity(0.12),
              child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                  style: const TextStyle(
                      color: _G4.purple,
                      fontWeight: FontWeight.w800,
                      fontSize: 24))),
          const SizedBox(height: 12),
          Text(name, style: _G4.poppins(size: 18, weight: FontWeight.w700)),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
                color: _G4.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20)),
            child: Text('Active Member',
                style: TextStyle(
                    color: _G4.green,
                    fontSize: 11,
                    fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 18),
          GestureDetector(
            onTap: () => _launch('tel:$phone'),
            child: _detailTile(Icons.phone_android_rounded, 'Phone', phone,
                tappable: true),
          ),
          GestureDetector(
            onTap: () => _launch('mailto:$email'),
            child: _detailTile(Icons.mail_outline_rounded, 'Email', email,
                tappable: true),
          ),
          GestureDetector(
            onTap: () => _launch(
                'https://maps.google.com/?q=${Uri.encodeComponent(address)}'),
            child: _detailTile(Icons.location_on_outlined, 'Address', address,
                tappable: true),
          ),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(
              child: _actionBtn('EDIT MEMBER', _G4.blue, outlined: true,
                  onTap: () {
                Navigator.pop(context);
                _editMember(context, doc);
              }),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _actionBtn('💳 PAYMENT', _G4.purple, onTap: () {
                Navigator.pop(context);
                _manualPay(context, doc.id, name);
              }),
            ),
          ]),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: () => _confirmDelete(context, doc.id, name),
            icon: Icon(Icons.delete_outline_rounded, color: _G4.red, size: 18),
            label: Text('Remove Member',
                style: TextStyle(color: _G4.red, fontWeight: FontWeight.w600)),
          ),
        ]),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // EDIT MEMBER
  // ══════════════════════════════════════════════════════════
  void _editMember(BuildContext context, DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final nameCtrl = TextEditingController(text: data['name'] ?? '');
    final phoneCtrl = TextEditingController(text: data['phone'] ?? '');
    final emailCtrl = TextEditingController(text: data['email'] ?? '');
    final addressCtrl = TextEditingController(text: data['address'] ?? '');

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Edit Member',
            style: _G4.poppins(size: 15, weight: FontWeight.w700)),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            _editField(nameCtrl, 'Full Name', Icons.person_rounded),
            const SizedBox(height: 10),
            _editField(phoneCtrl, 'Phone', Icons.phone_android_rounded,
                type: TextInputType.phone),
            const SizedBox(height: 10),
            _editField(emailCtrl, 'Email', Icons.mail_outline_rounded,
                type: TextInputType.emailAddress),
            const SizedBox(height: 10),
            _editField(addressCtrl, 'Address', Icons.location_on_outlined,
                maxLines: 2),
          ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: _G4.blue,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10))),
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              await FirebaseFirestore.instance
                  .collection('users')
                  .doc(doc.id)
                  .update({
                'name': nameCtrl.text.trim(),
                'phone': phoneCtrl.text.trim(),
                'email': emailCtrl.text.trim(),
                'address': addressCtrl.text.trim(),
                'updatedAt': FieldValue.serverTimestamp(),
              });
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('SAVE', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _editField(
    TextEditingController ctrl,
    String label,
    IconData icon, {
    TextInputType type = TextInputType.text,
    int maxLines = 1,
  }) {
    return TextField(
      controller: ctrl,
      keyboardType: type,
      maxLines: maxLines,
      style: _G4.poppins(size: 13),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: _G4.purple.withOpacity(0.5), size: 18),
        filled: true,
        fillColor: Colors.white.withOpacity(0.6),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: _G4.purple.withOpacity(0.15))),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: _G4.purple.withOpacity(0.15))),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: _G4.purple, width: 1.5)),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // DELETE MEMBER
  // ══════════════════════════════════════════════════════════
  void _confirmDelete(BuildContext context, String docId, String name) {
    Navigator.pop(context);
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text('Remove Member',
                  style: _G4.poppins(size: 15, weight: FontWeight.w700)),
              content: Text('This will permanently delete $name from LLCET.',
                  style: _G4.poppins(size: 13, color: _G4.midPurple)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _G4.red,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  onPressed: () async {
                    Navigator.pop(context);
                    await FirebaseFirestore.instance
                        .collection('users')
                        .doc(docId)
                        .delete();
                  },
                  child: const Text('Delete',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ));
  }

// ══════════════════════════════════════════════════════════════
  // _manualPay — with History + Edit + Delete + Close
  // ══════════════════════════════════════════════════════════════
  void _manualPay(BuildContext context, String uid, String name) {
    const months = [
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
      'January',
      'February',
      'March'
    ];
    const methods = ['Cash', 'UPI', 'Bank Transfer', 'Cheque'];

    int selIdx = _currentMonthIdx;
    String selFY = _currentFY;
    String selMethod = 'Cash';
    final amtCtrl = TextEditingController(text: '');

    // Edit mode state
    String? editDocId;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setS) {
          void loadEdit(DocumentSnapshot doc) {
            final d = doc.data() as Map<String, dynamic>;
            setS(() {
              editDocId = doc.id;
              amtCtrl.text = (d['amount'] ?? 500).toString();
              selIdx = d['fiscalIndex'] ?? 0;
              selFY = d['academicYear'] ?? _currentFY;
              selMethod = d['method'] ?? 'Cash';
            });
          }

          void resetForm() {
            setS(() {
              editDocId = null;
              amtCtrl.text = '';
              selIdx = _currentMonthIdx;
              selFY = _currentFY;
              selMethod = 'Cash';
            });
          }

          return Padding(
            padding:
                EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              child: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  // ── Handle + Close row ──
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const SizedBox(width: 32),
                        Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                              color: _G4.purple.withOpacity(0.18),
                              borderRadius: BorderRadius.circular(2)),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.pop(ctx),
                          child: Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                                color: _G4.midPurple.withOpacity(0.1),
                                shape: BoxShape.circle),
                            child: Icon(Icons.close_rounded,
                                size: 18, color: _G4.midPurple),
                          ),
                        ),
                      ]),
                  const SizedBox(height: 14),

                  // ── Header ──
                  Row(children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: _G4.purple.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12)),
                      child: Center(
                          child: Text(editDocId != null ? '✏️' : '💰',
                              style: const TextStyle(fontSize: 22))),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          Text(
                              editDocId != null
                                  ? 'Edit Payment'
                                  : 'Record Payment',
                              style: _G4.poppins(
                                  size: 15, weight: FontWeight.w700)),
                          Text(name,
                              style:
                                  _G4.poppins(size: 12, color: _G4.midPurple),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis),
                        ])),
                    if (editDocId != null)
                      GestureDetector(
                        onTap: resetForm,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                              color: _G4.orange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: _G4.orange.withOpacity(0.3))),
                          child: Text('+ New',
                              style: TextStyle(
                                  color: _G4.orange,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600)),
                        ),
                      ),
                  ]),
                  const SizedBox(height: 16),

                  // ── Amount input ──
                  Container(
                    decoration: BoxDecoration(
                      color: _G4.purple.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: editDocId != null
                              ? _G4.orange.withOpacity(0.4)
                              : _G4.purple.withOpacity(0.15)),
                    ),
                    child: TextField(
                      controller: amtCtrl,
                      keyboardType: TextInputType.number,
                      style: _G4.poppins(size: 26, weight: FontWeight.w800),
                      textAlign: TextAlign.center,
                      onChanged: (_) => setS(() {}),
                      decoration: InputDecoration(
                        hintText: 'Enter amount',
                        hintStyle: _G4.poppins(
                            size: 26,
                            weight: FontWeight.w800,
                            color: _G4.midPurple.withOpacity(0.3)),
                        prefixIcon: Padding(
                          padding: const EdgeInsets.only(left: 14, top: 15),
                          child: Text('₹',
                              style: _G4.poppins(
                                  size: 20,
                                  weight: FontWeight.w700,
                                  color: editDocId != null
                                      ? _G4.orange
                                      : _G4.purple)),
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 16, horizontal: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ── Month chips ──
                  SizedBox(
                    height: 38,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: months.length,
                      itemBuilder: (_, i) {
                        final sel = selIdx == i;
                        return GestureDetector(
                          onTap: () => setS(() => selIdx = i),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 8),
                            decoration: BoxDecoration(
                              color: sel
                                  ? _G4.purple
                                  : _G4.purple.withOpacity(0.07),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(months[i].substring(0, 3),
                                style: TextStyle(
                                    color: sel ? Colors.white : _G4.midPurple,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12)),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ── FY + Method row ──
                  Row(children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 2),
                        decoration: BoxDecoration(
                          color: _G4.purple.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(12),
                          border:
                              Border.all(color: _G4.purple.withOpacity(0.15)),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selFY,
                            icon: Icon(Icons.expand_more_rounded,
                                color: _G4.purple, size: 18),
                            style: _G4.poppins(size: 12),
                            items: [
                              '2024-2025',
                              '2025-2026',
                              '2026-2027',
                              '2027-2028'
                            ]
                                .map((y) =>
                                    DropdownMenuItem(value: y, child: Text(y)))
                                .toList(),
                            onChanged: (v) => setS(() => selFY = v!),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 2),
                        decoration: BoxDecoration(
                          color: _G4.green.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _G4.green.withOpacity(0.2)),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selMethod,
                            icon: Icon(Icons.expand_more_rounded,
                                color: _G4.green, size: 18),
                            style: _G4.poppins(size: 12, color: _G4.green),
                            items: methods
                                .map((m) =>
                                    DropdownMenuItem(value: m, child: Text(m)))
                                .toList(),
                            onChanged: (v) => setS(() => selMethod = v!),
                          ),
                        ),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 12),

                  // ── Live summary preview ──
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: editDocId != null
                          ? _G4.orange.withOpacity(0.06)
                          : _G4.green.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: editDocId != null
                              ? _G4.orange.withOpacity(0.25)
                              : _G4.green.withOpacity(0.2)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(months[selIdx],
                                  style: _G4.poppins(
                                      size: 12, weight: FontWeight.w700)),
                              Text(selFY,
                                  style: _G4.poppins(
                                      size: 10, color: _G4.midPurple)),
                            ]),
                        Row(children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                                color:
                                    (editDocId != null ? _G4.orange : _G4.green)
                                        .withOpacity(0.12),
                                borderRadius: BorderRadius.circular(6)),
                            child: Text(selMethod,
                                style: TextStyle(
                                    color: editDocId != null
                                        ? _G4.orange
                                        : _G4.green,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10.5)),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '₹${amtCtrl.text.isEmpty ? "0" : amtCtrl.text}',
                            style: _G4.poppins(
                                size: 16,
                                weight: FontWeight.w800,
                                color:
                                    editDocId != null ? _G4.orange : _G4.green),
                          ),
                        ]),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ── Save / Update button ──
                  GestureDetector(
                    onTap: () async {
                      final amt = double.tryParse(amtCtrl.text.trim()) ?? 500.0;
                      final payload = {
                        'volunteerId': uid,
                        'uid': uid,
                        'memberName': name,
                        'amount': amt,
                        'fiscalIndex': selIdx,
                        'month': months[selIdx],
                        'status': 'Paid',
                        'method': selMethod,
                        'transactionId':
                            'MANUAL-${selMethod.toUpperCase().replaceAll(' ', '_')}',
                        'academicYear': selFY,
                        'recordedBy': widget.adminUid,
                        'submittedAt': FieldValue.serverTimestamp(),
                      };
                      if (editDocId != null) {
                        await FirebaseFirestore.instance
                            .collection('contributions')
                            .doc(editDocId)
                            .update(payload);
                      } else {
                        await FirebaseFirestore.instance
                            .collection('contributions')
                            .add(payload);
                      }
                      if (ctx.mounted) {
                        resetForm();
                      }
                    },
                    child: Container(
                      width: double.infinity,
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            colors: editDocId != null
                                ? [_G4.orange, const Color(0xFFF57C00)]
                                : [_G4.green, const Color(0xFF43A047)],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                              color:
                                  (editDocId != null ? _G4.orange : _G4.green)
                                      .withOpacity(0.35),
                              blurRadius: 12,
                              offset: const Offset(0, 4))
                        ],
                      ),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                                editDocId != null
                                    ? Icons.update_rounded
                                    : Icons.check_rounded,
                                color: Colors.white,
                                size: 20),
                            const SizedBox(width: 8),
                            Text(
                                editDocId != null
                                    ? 'UPDATE PAYMENT'
                                    : 'SAVE PAYMENT',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                    letterSpacing: 0.8)),
                          ]),
                    ),
                  ),

                  // ── Past Payments History ──
                  const SizedBox(height: 20),
                  Divider(color: _G4.purple.withOpacity(0.1)),
                  const SizedBox(height: 8),
                  Row(children: [
                    Icon(Icons.history_rounded, size: 15, color: _G4.midPurple),
                    const SizedBox(width: 6),
                    Text('Past Payments',
                        style: TextStyle(
                            color: _G4.midPurple,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.6)),
                  ]),
                  const SizedBox(height: 10),

                  StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('contributions')
                        .where('volunteerId', isEqualTo: uid)
                        .snapshots(),
                    builder: (_, snap) {
                      if (!snap.hasData || snap.data!.docs.isEmpty) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Text('No payments recorded yet.',
                              style:
                                  _G4.poppins(size: 12, color: _G4.midPurple)),
                        );
                      }
                      return Column(
                        children: snap.data!.docs.map((doc) {
                          final d = doc.data() as Map<String, dynamic>;
                          final isEditing = editDocId == doc.id;
                          return Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: isEditing
                                  ? _G4.orange.withOpacity(0.08)
                                  : _G4.purple.withOpacity(0.04),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: isEditing
                                      ? _G4.orange.withOpacity(0.4)
                                      : _G4.purple.withOpacity(0.08)),
                            ),
                            child: Row(children: [
                              Expanded(
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                    Row(children: [
                                      Text(d['month'] ?? '',
                                          style: _G4.poppins(
                                              size: 12,
                                              weight: FontWeight.w700)),
                                      const SizedBox(width: 6),
                                      Text(d['academicYear'] ?? '',
                                          style: _G4.poppins(
                                              size: 10, color: _G4.midPurple)),
                                    ]),
                                    const SizedBox(height: 2),
                                    Row(children: [
                                      Text('₹${d['amount'] ?? 0}',
                                          style: _G4.poppins(
                                              size: 13,
                                              weight: FontWeight.w700,
                                              color: _G4.green)),
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 7, vertical: 2),
                                        decoration: BoxDecoration(
                                            color: _G4.green.withOpacity(0.1),
                                            borderRadius:
                                                BorderRadius.circular(5)),
                                        child: Text(d['method'] ?? 'Cash',
                                            style: TextStyle(
                                                color: _G4.green,
                                                fontSize: 9.5,
                                                fontWeight: FontWeight.w600)),
                                      ),
                                    ]),
                                  ])),
                              // Edit button
                              GestureDetector(
                                onTap: () => loadEdit(doc),
                                child: Container(
                                  margin: const EdgeInsets.only(right: 8),
                                  padding: const EdgeInsets.all(7),
                                  decoration: BoxDecoration(
                                      color: _G4.orange.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8)),
                                  child: Icon(Icons.edit_rounded,
                                      size: 15, color: _G4.orange),
                                ),
                              ),
                              // Delete button
                              GestureDetector(
                                onTap: () async {
                                  final confirmed = await showDialog<bool>(
                                    context: ctx,
                                    builder: (_) => AlertDialog(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(18)),
                                      title: Text('Delete Payment',
                                          style: _G4.poppins(
                                              size: 14,
                                              weight: FontWeight.w700)),
                                      content: Text(
                                          'Delete ${d['month']} ₹${d['amount']} entry?',
                                          style: _G4.poppins(
                                              size: 12, color: _G4.midPurple)),
                                      actions: [
                                        TextButton(
                                            onPressed: () =>
                                                Navigator.pop(ctx, false),
                                            child: const Text('Cancel')),
                                        ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                              backgroundColor: _G4.red,
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          10))),
                                          onPressed: () =>
                                              Navigator.pop(ctx, true),
                                          child: const Text('Delete',
                                              style: TextStyle(
                                                  color: Colors.white)),
                                        ),
                                      ],
                                    ),
                                  );
                                  if (confirmed == true) {
                                    await FirebaseFirestore.instance
                                        .collection('contributions')
                                        .doc(doc.id)
                                        .delete();
                                    if (editDocId == doc.id) {
                                      resetForm();
                                    }
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(7),
                                  decoration: BoxDecoration(
                                      color: _G4.red.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8)),
                                  child: Icon(Icons.delete_outline_rounded,
                                      size: 15, color: _G4.red),
                                ),
                              ),
                            ]),
                          );
                        }).toList(),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // SHARED HELPERS
  // ══════════════════════════════════════════════════════════
  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  Widget _infoRow(IconData icon, String text, {bool tappable = false}) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, size: 15, color: tappable ? _G4.purple : _G4.midPurple),
      const SizedBox(width: 8),
      Expanded(
          child: Text(text,
              style: TextStyle(
                  color: tappable ? _G4.purple : _G4.midPurple,
                  fontSize: 12,
                  fontWeight: tappable ? FontWeight.w600 : FontWeight.w500,
                  decoration: tappable ? TextDecoration.underline : null))),
    ]);
  }

  Widget _detailTile(IconData icon, String label, String value,
      {bool tappable = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: tappable
            ? _G4.purple.withOpacity(0.05)
            : Colors.white.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: tappable
                ? _G4.purple.withOpacity(0.15)
                : Colors.white.withOpacity(0.8)),
      ),
      child: Row(children: [
        Icon(icon, size: 18, color: tappable ? _G4.purple : _G4.midPurple),
        const SizedBox(width: 12),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label,
              style: TextStyle(
                  color: _G4.midPurple,
                  fontSize: 10,
                  fontWeight: FontWeight.w500)),
          Text(value,
              style: _G4.poppins(
                  size: 13,
                  color: tappable ? _G4.purple : _G4.deepPurple,
                  weight: tappable ? FontWeight.w600 : FontWeight.w500)),
        ])),
        if (tappable)
          Icon(Icons.open_in_new_rounded, size: 14, color: _G4.purple),
      ]),
    );
  }

  Widget _emptyState(IconData icon, String title, String sub) {
    return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, size: 52, color: _G4.purple.withOpacity(0.25)),
      const SizedBox(height: 14),
      Text(title, style: _G4.poppins(size: 15, weight: FontWeight.w600)),
      const SizedBox(height: 6),
      Text(sub, style: _G4.poppins(size: 11.5, color: _G4.midPurple)),
    ]));
  }

  Widget _actionBtn(String label, Color color,
      {required VoidCallback onTap, bool outlined = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 44,
        decoration: BoxDecoration(
          gradient: outlined
              ? null
              : LinearGradient(
                  colors: [
                    color.withRed((color.red - 30).clamp(0, 255)),
                    color,
                    color.withBlue((color.blue + 20).clamp(0, 255))
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
          color: outlined ? color.withOpacity(0.08) : null,
          borderRadius: BorderRadius.circular(11),
          border: outlined ? Border.all(color: color.withOpacity(0.3)) : null,
          boxShadow: outlined
              ? []
              : [
                  BoxShadow(
                      color: color.withOpacity(0.3),
                      blurRadius: 10,
                      offset: const Offset(0, 4))
                ],
        ),
        child: Center(
            child: Text(label,
                style: TextStyle(
                    color: outlined ? color : Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                    letterSpacing: 0.8))),
      ),
    );
  }
}

// ── Data model ────────────────────────────────────────────────
class _MemberSlide {
  final String label, value, emoji;
  final List<Color> colors;
  const _MemberSlide(this.label, this.value, this.emoji, this.colors);
}
