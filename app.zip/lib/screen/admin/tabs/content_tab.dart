// ══════════════════════════════════════════════════════════════
// content_tab.dart
// Tab 5 — Content (Announcements · Events · Polls + FAB)
// LLCET Admin Panel · G4 Design
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/g4_theme.dart';
import '../utils/g4_sheet.dart';

class ContentTab extends StatelessWidget {
  const ContentTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: G4.bg,
      floatingActionButton: FloatingActionButton(
        backgroundColor: G4.purple,
        onPressed: () => _showCreateMenu(context),
        child: const Icon(Icons.add_rounded, color: Colors.white),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(16),
        children: [
          _sectionTitle('Active Polls'),
          _buildPolls(context),
          const SizedBox(height: 16),
          _sectionTitle('Announcements'),
          _buildStream(context, 'announcements'),
          const SizedBox(height: 16),
          _sectionTitle('Events'),
          _buildStream(context, 'events'),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  // ── Section Title ─────────────────────────────────────────
  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(t, style: G4.poppins(size: 13, weight: FontWeight.w700)),
      );

  // ── Announcements / Events Stream ────────────────────────
  Widget _buildStream(BuildContext context, String coll) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection(coll)
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (_, snap) {
        if (!snap.hasData || snap.data!.docs.isEmpty) {
          return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Text('No $coll yet.',
                  style: G4.poppins(size: 12, color: G4.midPurple)));
        }
        return Column(
            children: snap.data!.docs.map((d) {
          final data = d.data() as Map<String, dynamic>;
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            decoration: G4.glassCard(),
            child: ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              leading: data['imageUrl'] != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(data['imageUrl'],
                          width: 44, height: 44, fit: BoxFit.cover))
                  : Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: G4.purple.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8)),
                      child: Icon(
                          coll == 'events'
                              ? Icons.event_rounded
                              : Icons.campaign_rounded,
                          color: G4.purple)),
              title: Text(data['title'] ?? '',
                  style: G4.poppins(size: 13, weight: FontWeight.w600)),
              subtitle:
                  data['date'] != null && (data['date'] as String).isNotEmpty
                      ? Text(data['date'],
                          style: G4.poppins(size: 11, color: G4.midPurple))
                      : null,
              trailing: IconButton(
                icon: Icon(Icons.delete_outline_rounded,
                    color: G4.midPurple, size: 20),
                onPressed: () =>
                    _confirmDelete(context, d.reference, data['title'] ?? coll),
              ),
            ),
          );
        }).toList());
      },
    );
  }

  // ── Polls Stream ─────────────────────────────────────────
  Widget _buildPolls(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('polls')
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (_, snap) {
        if (!snap.hasData || snap.data!.docs.isEmpty) {
          return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Text('No active polls.',
                  style: G4.poppins(size: 12, color: G4.midPurple)));
        }
        return Column(
            children: snap.data!.docs.map((doc) {
          final data = doc.data() as Map<String, dynamic>;
          final options = List<String>.from(data['options'] ?? []);
          final votes = (data['votes'] as Map<dynamic, dynamic>?) ?? {};
          final totalVotes = votes.length;

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: G4.glassCard(),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Expanded(
                    child: Text(data['question'] ?? '',
                        style: G4.poppins(size: 13, weight: FontWeight.w700))),
                IconButton(
                    icon: Icon(Icons.delete_outline_rounded,
                        color: G4.midPurple, size: 18),
                    onPressed: () => _confirmDelete(
                        context, doc.reference, data['question'] ?? 'Poll')),
              ]),
              Text('$totalVotes vote${totalVotes == 1 ? '' : 's'}',
                  style: G4.poppins(size: 10, color: G4.midPurple)),
              const SizedBox(height: 10),
              ...options.map((opt) {
                final count = votes.values.where((v) => v == opt).length;
                final progress = totalVotes == 0 ? 0.0 : count / totalVotes;
                return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(opt,
                                  style: G4.poppins(
                                      size: 12, color: G4.midPurple)),
                              Text('$count',
                                  style: G4.poppins(
                                      size: 11,
                                      color: G4.purple,
                                      weight: FontWeight.w600)),
                            ]),
                        const SizedBox(height: 4),
                        ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                                value: progress,
                                minHeight: 6,
                                color: G4.purple,
                                backgroundColor: G4.purple.withOpacity(0.1))),
                      ],
                    ));
              }),
            ]),
          );
        }).toList());
      },
    );
  }

  // ── FAB Create Menu ──────────────────────────────────────
  void _showCreateMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => G4Sheet(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Create New',
              style: G4.poppins(size: 16, weight: FontWeight.w700)),
          const SizedBox(height: 16),
          _menuTile(context, Icons.campaign_rounded, 'Announcement',
              'Publish to all members', () {
            Navigator.pop(context);
            _addContent(context, 'announcements');
          }),
          _menuTile(context, Icons.event_rounded, 'Event', 'Add upcoming event',
              () {
            Navigator.pop(context);
            _addContent(context, 'events');
          }),
          _menuTile(context, Icons.poll_rounded, 'Poll', 'Create a vote', () {
            Navigator.pop(context);
            _addPoll(context);
          }),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Widget _menuTile(BuildContext context, IconData icon, String title,
      String sub, VoidCallback onTap) {
    return ListTile(
      leading: Container(
          padding: const EdgeInsets.all(9),
          decoration: BoxDecoration(
              color: G4.purple.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: G4.purple, size: 20)),
      title:
          Text(title, style: G4.poppins(size: 13.5, weight: FontWeight.w600)),
      subtitle: Text(sub, style: G4.poppins(size: 11, color: G4.midPurple)),
      onTap: onTap,
    );
  }

  // ── Add Announcement / Event ─────────────────────────────
  void _addContent(BuildContext context, String coll) {
    final titleC = TextEditingController();
    final imgC = TextEditingController();
    final dateC = TextEditingController();
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text(
                  'New ${coll == 'announcements' ? 'Announcement' : 'Event'}',
                  style: G4.poppins(size: 15, weight: FontWeight.w700)),
              content: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(
                    controller: titleC,
                    style: G4.poppins(size: 13),
                    decoration: const InputDecoration(labelText: 'Title *')),
                const SizedBox(height: 12),
                TextField(
                    controller: dateC,
                    style: G4.poppins(size: 13),
                    decoration: const InputDecoration(
                        labelText: 'Date / Subtitle',
                        hintText: 'e.g. May 15, 2026')),
                const SizedBox(height: 12),
                TextField(
                    controller: imgC,
                    style: G4.poppins(size: 13),
                    decoration: const InputDecoration(
                        labelText: 'Image URL (optional)',
                        hintText: 'Paste image link')),
              ])),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: G4.purple,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  onPressed: () async {
                    if (titleC.text.trim().isEmpty) return;
                    await FirebaseFirestore.instance.collection(coll).add({
                      'title': titleC.text.trim(),
                      'date': dateC.text.trim(),
                      'imageUrl':
                          imgC.text.trim().isEmpty ? null : imgC.text.trim(),
                      'createdAt': FieldValue.serverTimestamp(),
                    });
                    if (context.mounted) Navigator.pop(context);
                  },
                  child:
                      const Text('POST', style: TextStyle(color: Colors.white)),
                ),
              ],
            ));
  }

  // ── Add Poll ─────────────────────────────────────────────
  void _addPoll(BuildContext context) {
    final qC = TextEditingController();
    final opts = [
      TextEditingController(text: 'Yes'),
      TextEditingController(text: 'No')
    ];
    showDialog(
        context: context,
        builder: (_) => StatefulBuilder(
              builder: (ctx, setS) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                title: Text('Create Poll',
                    style: G4.poppins(size: 15, weight: FontWeight.w700)),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: qC,
                      style: G4.poppins(size: 13),
                      decoration:
                          const InputDecoration(labelText: 'Question *')),
                  ...opts.asMap().entries.map((e) => Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: TextField(
                            controller: e.value,
                            style: G4.poppins(size: 13),
                            decoration: InputDecoration(
                                labelText: 'Option ${e.key + 1}')),
                      )),
                  TextButton.icon(
                    onPressed: () =>
                        setS(() => opts.add(TextEditingController())),
                    icon: const Icon(Icons.add_rounded, size: 16),
                    label: const Text('Add Option'),
                  ),
                ])),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Cancel')),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: G4.purple,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    onPressed: () async {
                      if (qC.text.trim().isEmpty) return;
                      await FirebaseFirestore.instance.collection('polls').add({
                        'question': qC.text.trim(),
                        'options': opts
                            .map((e) => e.text.trim())
                            .where((t) => t.isNotEmpty)
                            .toList(),
                        'votes': {},
                        'createdAt': FieldValue.serverTimestamp(),
                      });
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
                    child: const Text('CREATE',
                        style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ));
  }

  // ── Delete Confirmation ──────────────────────────────────
  void _confirmDelete(
      BuildContext context, DocumentReference ref, String label) {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text('Delete',
                  style: G4.poppins(size: 15, weight: FontWeight.w700)),
              content: Text('Remove "$label"?',
                  style: G4.poppins(size: 13, color: G4.midPurple)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: G4.red,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  onPressed: () async {
                    Navigator.pop(context);
                    await ref.delete();
                  },
                  child: const Text('Delete',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ));
  }
}
