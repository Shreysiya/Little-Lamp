// ══════════════════════════════════════════════════════════════
// dashboard_tab.dart
// Tab 1 — Dashboard (FY Selector, Hero Card, Stat Chips,
//          Banner Carousel, Recent Activity)
// LLCET Admin Panel · G4 Design
// ══════════════════════════════════════════════════════════════

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';

// ── G4 Design Tokens ─────────────────────────────────────────
class _G4 {
  static const bg = Color(0xFFEDE6FF);
  static const deepPurple = Color(0xFF2D1B4E);
  static const purple = Color(0xFF5B2D8E);
  static const midPurple = Color(0xFF6B5A8A);
  static const orange = Color(0xFFF5840C);
  static const blue = Color(0xFF5BAEE8);
  static const green = Color(0xFF2E7D52);
  static const red = Color(0xFFB00020);

  static BoxDecoration glassCard({Color? shadow}) => BoxDecoration(
        color: Colors.white.withOpacity(0.62),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.9), width: 1.5),
        boxShadow: [
          BoxShadow(
              color: (shadow ?? purple).withOpacity(0.09),
              blurRadius: 16,
              offset: const Offset(0, 4))
        ],
      );

  static TextStyle poppins(
          {double size = 14,
          FontWeight weight = FontWeight.w600,
          Color? color}) =>
      GoogleFonts.poppins(
          fontSize: size, fontWeight: weight, color: color ?? deepPurple);
}

// ── Shared Bottom Sheet ───────────────────────────────────────
class _G4Sheet extends StatelessWidget {
  final Widget child;
  const _G4Sheet({required this.child});
  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFFEDE6FF),
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: const Color(0xFF5B2D8E).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 20),
          child,
        ]),
      );
}

// ══════════════════════════════════════════════════════════════
// DashboardTab — public class (used in admin_home.dart)
// ══════════════════════════════════════════════════════════════
class DashboardTab extends StatefulWidget {
  final String selectedFY;
  final ValueChanged<String> onFYChanged;
  final ValueChanged<int> onTabTap;
  const DashboardTab({
    super.key,
    required this.selectedFY,
    required this.onFYChanged,
    required this.onTabTap,
  });
  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  final PageController _bannerCtrl = PageController(viewportFraction: 0.88);
  int _currentBanner = 0;
  int _bannerCount = 1;
  Timer? _timer;

  // FY list — auto-includes current FY
  List<String> get _fYears {
    final now = DateTime.now();
    final start = now.month >= 4 ? now.year - 1 : now.year - 2;
    return List.generate(4, (i) => '${start + i}-${start + i + 1}');
  }

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 3500), (_) {
      if (!mounted || !_bannerCtrl.hasClients) return;
      final next = (_currentBanner + 1) % _bannerCount;
      _bannerCtrl.animateToPage(next,
          duration: const Duration(milliseconds: 520),
          curve: Curves.easeInOutCubic);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _bannerCtrl.dispose();
    super.dispose();
  }

  // ── AUTO FY HELPER ────────────────────────────────────────
  String get _currentFY {
    final now = DateTime.now();
    final s = now.month >= 4 ? now.year : now.year - 1;
    return '$s-${s + 1}';
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (ctx, userSnap) => StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('contributions')
            .where('academicYear', isEqualTo: widget.selectedFY)
            .snapshots(),
        builder: (ctx, paySnap) {
          final totalMembers = !userSnap.hasData
              ? 0
              : userSnap.data!.docs
                  .where((d) => _safe(d, 'status') == 'approved')
                  .length;
          final pendingCount = !userSnap.hasData
              ? 0
              : userSnap.data!.docs
                  .where((d) => _safe(d, 'status') == 'pending')
                  .length;
          final pendingVerify = !paySnap.hasData
              ? 0
              : paySnap.data!.docs
                  .where((d) => _safe(d, 'status') == 'Awaiting Approval')
                  .length;
          final totalAmount = !paySnap.hasData
              ? 0.0
              : paySnap.data!.docs
                  .where((d) => _safe(d, 'status') == 'Paid')
                  .fold(
                      0.0, (s, d) => s + (_safeMap(d)['amount'] as num? ?? 0));
          final monthDocs =
              paySnap.hasData ? paySnap.data!.docs : <QueryDocumentSnapshot>[];

          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _fySelector(),
              const SizedBox(height: 2),
              _heroCard(context, totalAmount, totalMembers, monthDocs),
              const SizedBox(height: 14),
              _statChips(context, totalMembers, pendingCount, pendingVerify),
              const SizedBox(height: 18),
              _sectionHead(context, 'Events & Updates', 'See All →',
                  onTap: () => widget.onTabTap(4)),
              _bannerCarousel(context),
              const SizedBox(height: 18),
              _sectionHead(context, 'Recent Activity', 'View All →',
                  onTap: () => widget.onTabTap(2)),
              _recentActivity(context, paySnap, userSnap),
              const SizedBox(height: 28),
            ]),
          );
        },
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // FY SELECTOR
  // ══════════════════════════════════════════════════════════
  Widget _fySelector() {
    return SizedBox(
      height: 48,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _fYears.length,
        itemBuilder: (_, i) {
          final sel = widget.selectedFY == _fYears[i];
          return GestureDetector(
            onTap: () => widget.onFYChanged(_fYears[i]),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: sel ? _G4.purple : Colors.white.withOpacity(0.65),
                borderRadius: BorderRadius.circular(11),
                border: Border.all(
                    color: sel ? _G4.purple : _G4.purple.withOpacity(0.15)),
                boxShadow: sel
                    ? [
                        BoxShadow(
                            color: _G4.purple.withOpacity(0.35),
                            blurRadius: 10,
                            offset: const Offset(0, 3))
                      ]
                    : [],
              ),
              alignment: Alignment.center,
              child: Text(_fYears[i],
                  style: TextStyle(
                    color: sel ? Colors.white : _G4.midPurple,
                    fontWeight: FontWeight.w700,
                    fontSize: 11.5,
                  )),
            ),
          );
        },
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // HERO CARD — tappable → monthly breakdown
  // ══════════════════════════════════════════════════════════
  Widget _heroCard(BuildContext context, double total, int members,
      List<QueryDocumentSnapshot> docs) {
    return GestureDetector(
      onTap: () => _showMonthlyBreakdown(context, docs),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF3B1A6B), Color(0xFF5B2D8E), Color(0xFF7B3FAF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
                color: _G4.purple.withOpacity(0.45),
                blurRadius: 24,
                offset: const Offset(0, 8))
          ],
        ),
        child: Stack(children: [
          Positioned(
              top: -30,
              right: -30,
              child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.07)))),
          Positioned(
              bottom: -20,
              left: -20,
              child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _G4.orange.withOpacity(0.12)))),
          Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
            Text('TOTAL COLLECTED · ${widget.selectedFY}',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.6),
                    fontSize: 9.5,
                    letterSpacing: 1.2,
                    fontWeight: FontWeight.w600),
                textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text('₹${total.toStringAsFixed(0)}',
                style: _G4.poppins(
                    size: 30, weight: FontWeight.w900, color: Colors.white),
                textAlign: TextAlign.center),
            const SizedBox(height: 12),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _heroPill('👥 $members Members'),
              const SizedBox(width: 8),
              _heroPill('📅 ${_monthName()}'),
              const SizedBox(width: 8),
              _heroPill('👆 Tap for details'),
            ]),
          ]),
          Positioned(
              top: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(8)),
                child: const Text('📈 +12%',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700)),
              )),
        ]),
      ),
    );
  }

  Widget _heroPill(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.16),
            borderRadius: BorderRadius.circular(7)),
        child: Text(text,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 9.5,
                fontWeight: FontWeight.w600)),
      );

  void _showMonthlyBreakdown(
      BuildContext context, List<QueryDocumentSnapshot> docs) {
    const months = [
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "January",
      "February",
      "March"
    ];
    double grand = 0;
    final rows = months.asMap().entries.map((e) {
      final t = docs
          .where((d) =>
              _safeMap(d)['fiscalIndex'] == e.key &&
              _safe(d, 'status') == 'Paid')
          .fold(0.0, (s, d) => s + (_safeMap(d)['amount'] as num? ?? 0));
      grand += t;
      return MapEntry(e.value, t);
    }).toList();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _G4Sheet(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Monthly Breakdown',
              style: _G4.poppins(size: 16, weight: FontWeight.w700)),
          Text(widget.selectedFY,
              style: _G4.poppins(size: 11, color: _G4.midPurple)),
          const SizedBox(height: 16),
          ...rows.map((r) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(r.key,
                          style: _G4.poppins(size: 13, color: _G4.midPurple)),
                      Text('₹${r.value.toStringAsFixed(0)}',
                          style: _G4.poppins(
                              size: 13,
                              weight: r.value > 0
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                              color: r.value > 0
                                  ? _G4.purple
                                  : _G4.midPurple.withOpacity(0.4))),
                    ]),
              )),
          Divider(color: _G4.purple.withOpacity(0.15), height: 24),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Grand Total',
                style: _G4.poppins(size: 14, weight: FontWeight.w700)),
            Text('₹${grand.toStringAsFixed(0)}',
                style: _G4.poppins(
                    size: 16, weight: FontWeight.w800, color: _G4.purple)),
          ]),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // STAT CHIPS
  // ══════════════════════════════════════════════════════════
  Widget _statChips(
      BuildContext context, int members, int pending, int verify) {
    final chips = [
      _ChipDef(
          '👥', '$members', 'Members', _G4.purple, () => widget.onTabTap(1)),
      _ChipDef(
          '⏳', '$pending', 'Requests', _G4.orange, () => widget.onTabTap(1)),
      _ChipDef('✅', '$verify', 'Verify', _G4.blue, () => widget.onTabTap(2)),
      _ChipDef('🚨', '!', 'Alerts', _G4.red, () => widget.onTabTap(3)),
      _ChipDef('📄', 'PDF', 'Reports', _G4.green, () => widget.onTabTap(3)),
    ];
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: chips.length,
        itemBuilder: (_, i) {
          final c = chips[i];
          return GestureDetector(
            onTap: c.onTap,
            child: Container(
              width: 92,
              margin: const EdgeInsets.only(right: 10),
              padding: const EdgeInsets.all(12),
              decoration: _G4.glassCard(shadow: c.color),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                          color: c.color.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(9)),
                      child: Center(
                          child: Text(c.emoji,
                              style: const TextStyle(fontSize: 15))),
                    ),
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(c.value,
                              style: _G4.poppins(
                                  size: 17, weight: FontWeight.w800)),
                          Text(c.label,
                              style: TextStyle(
                                  color: _G4.midPurple,
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w500)),
                        ]),
                  ]),
            ),
          );
        },
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // BANNER CAROUSEL
  // ══════════════════════════════════════════════════════════
  Widget _bannerCarousel(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('events').snapshots(),
      builder: (_, evtSnap) => StreamBuilder<QuerySnapshot>(
        stream:
            FirebaseFirestore.instance.collection('announcements').snapshots(),
        builder: (_, annSnap) {
          final items = <_BannerItem>[];
          if (evtSnap.hasData) {
            for (final d in evtSnap.data!.docs) {
              final data = _safeMap(d);
              items.add(_BannerItem(
                  tag: 'Event',
                  tagColor: _G4.purple,
                  emoji: '🎯',
                  gradients: [const Color(0xFF1a0840), _G4.purple],
                  title: data['title'] ?? '',
                  subtitle: data['date'] ?? 'Upcoming',
                  imageUrl: data['imageUrl']));
            }
          }
          if (annSnap.hasData) {
            for (final d in annSnap.data!.docs) {
              final data = _safeMap(d);
              items.add(_BannerItem(
                  tag: 'Announcement',
                  tagColor: _G4.orange,
                  emoji: '📢',
                  gradients: [const Color(0xFF2d1200), _G4.orange],
                  title: data['title'] ?? '',
                  subtitle: 'Posted by Admin',
                  imageUrl: data['imageUrl']));
            }
          }
          // Vision card always last
          items.add(_BannerItem(
              tag: 'Our Vision',
              tagColor: _G4.green,
              emoji: '🕯️',
              gradients: [const Color(0xFF1a3a1a), _G4.green],
              title: 'Quality Education for Every Child',
              subtitle: 'LLCET · Boisar, Maharashtra',
              imageUrl: null));
          if (items.length == 1) {
            items.insert(
                0,
                _BannerItem(
                    tag: 'Upcoming',
                    tagColor: _G4.blue,
                    emoji: '🏏',
                    gradients: [const Color(0xFF001428), _G4.blue],
                    title: 'LLCET Industrial Cup 2026',
                    subtitle: '📅 May 15, 2026',
                    imageUrl: null));
          }
          _bannerCount = items.length;

          return Column(children: [
            SizedBox(
              height: 148,
              child: PageView.builder(
                controller: _bannerCtrl,
                itemCount: items.length,
                onPageChanged: (i) => setState(() => _currentBanner = i),
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () => _showBannerDetail(context, items[i]),
                  child: _bannerCard(items[i]),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                  items.length,
                  (i) => AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: _currentBanner == i ? 18 : 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: _currentBanner == i
                              ? _G4.purple
                              : _G4.purple.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      )),
            ),
          ]);
        },
      ),
    );
  }

  Widget _bannerCard(_BannerItem item) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: item.imageUrl == null
            ? LinearGradient(
                colors: item.gradients,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight)
            : null,
        image: item.imageUrl != null
            ? DecorationImage(
                image: NetworkImage(item.imageUrl!), fit: BoxFit.cover)
            : null,
        boxShadow: [
          BoxShadow(
              color: item.tagColor.withOpacity(0.3),
              blurRadius: 14,
              offset: const Offset(0, 5))
        ],
      ),
      child: Stack(children: [
        if (item.imageUrl != null)
          Container(
              decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              colors: [Colors.transparent, Colors.black.withOpacity(0.72)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          )),
        if (item.imageUrl == null)
          Positioned(
              top: -15,
              right: -15,
              child: Text(item.emoji,
                  style: TextStyle(
                      fontSize: 68, color: Colors.white.withOpacity(0.1)))),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                      color: item.tagColor.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(6)),
                  child: Text(item.tag.toUpperCase(),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 8.5,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1)),
                ),
                const SizedBox(height: 8),
                Text(item.title,
                    style: _G4.poppins(
                        size: 14, weight: FontWeight.w700, color: Colors.white),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Text(item.subtitle,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.65), fontSize: 10.5)),
              ]),
        ),
      ]),
    );
  }

  void _showBannerDetail(BuildContext context, _BannerItem item) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _G4Sheet(
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (item.imageUrl != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.network(item.imageUrl!,
                      height: 180, width: double.infinity, fit: BoxFit.cover),
                )
              else
                Container(
                  height: 120,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: LinearGradient(
                        colors: item.gradients,
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight),
                  ),
                  child: Center(
                      child: Text(item.emoji,
                          style: const TextStyle(fontSize: 52))),
                ),
              const SizedBox(height: 16),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                    color: item.tagColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20)),
                child: Text(item.tag,
                    style: TextStyle(
                        color: item.tagColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 10),
              Text(item.title,
                  style: _G4.poppins(size: 17, weight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(item.subtitle,
                  style: _G4.poppins(size: 12, color: _G4.midPurple)),
              const SizedBox(height: 8),
            ]),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // RECENT ACTIVITY
  // ══════════════════════════════════════════════════════════
  Widget _recentActivity(
      BuildContext context,
      AsyncSnapshot<QuerySnapshot> paySnap,
      AsyncSnapshot<QuerySnapshot> userSnap) {
    if (!paySnap.hasData) return const SizedBox.shrink();
    final paid =
        paySnap.data!.docs.where((d) => _safe(d, 'status') == 'Paid').toList()
          ..sort((a, b) {
            final aT = _safeMap(a)['submittedAt'];
            final bT = _safeMap(b)['submittedAt'];
            if (aT == null || bT == null) return 0;
            return (bT as dynamic).compareTo(aT);
          });
    final recent = paid.take(5).toList();
    if (recent.isEmpty) {
      return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text('No payments yet',
              style: _G4.poppins(size: 12, color: _G4.midPurple)));
    }
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: _G4.glassCard(),
      child: Column(
        children: recent.asMap().entries.map((entry) {
          final doc = entry.value;
          final data = _safeMap(doc);
          // Resolve member name
          final rawName = (data['memberName'] ?? '').toString().trim();
          final uid =
              (data['volunteerId'] ?? data['uid'] ?? '').toString().trim();
          String name;
          if (rawName.isNotEmpty) {
            name = rawName;
          } else if (uid.isNotEmpty && userSnap.hasData) {
            final userDocs =
                userSnap.data!.docs.where((u) => u.id == uid).toList();
            if (userDocs.isNotEmpty) {
              final resolved = ((userDocs.first.data() as Map)['name'] ?? '')
                  .toString()
                  .trim();
              name = resolved.isNotEmpty ? resolved : 'Member';
            } else {
              name = 'Member';
            }
          } else {
            name = 'Member';
          }
          final month = data['month'] ?? '';
          final fy = data['academicYear'] ?? '';
          final fyYear = _shortYear(month, fy);
          final monthDisplay = month.isNotEmpty ? "$month '$fyYear" : '';
          final amount = data['amount'] ?? 0;
          final method = data['method'] ?? data['transactionId'] ?? '';
          final isLast = entry.key == recent.length - 1;

          return GestureDetector(
            onTap: () => _showPaymentDetail(context, data, doc.id),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                border: isLast
                    ? null
                    : Border(
                        bottom:
                            BorderSide(color: _G4.purple.withOpacity(0.07))),
              ),
              child: Row(children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _G4.purple.withOpacity(0.1)),
                  child: Center(
                      child: Text(
                    name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: TextStyle(
                        color: _G4.purple,
                        fontSize: 14,
                        fontWeight: FontWeight.w800),
                  )),
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text(name,
                          style:
                              _G4.poppins(size: 12.5, weight: FontWeight.w600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      Text('$monthDisplay · $method',
                          style: TextStyle(color: _G4.midPurple, fontSize: 10)),
                    ])),
                Text('+₹$amount',
                    style: _G4.poppins(
                        size: 13, weight: FontWeight.w700, color: _G4.green)),
              ]),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // PAYMENT DETAIL SHEET  (with Edit + Delete)
  // ══════════════════════════════════════════════════════════
  void _showPaymentDetail(
      BuildContext context, Map<String, dynamic> data, String docId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _G4Sheet(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
                shape: BoxShape.circle, color: _G4.green.withOpacity(0.12)),
            child:
                const Center(child: Text('💳', style: TextStyle(fontSize: 26))),
          ),
          const SizedBox(height: 14),
          Text('Payment Details',
              style: _G4.poppins(size: 16, weight: FontWeight.w700)),
          const SizedBox(height: 16),
          _detailRow(
              'Member', data['memberName'] ?? data['volunteerId'] ?? 'N/A'),
          _detailRow('Month', data['month'] ?? 'N/A'),
          _detailRow('Amount', '₹${data['amount'] ?? 0}'),
          _detailRow(
              'Method', data['method'] ?? data['transactionId'] ?? 'N/A'),
          _detailRow('Status', data['status'] ?? 'N/A'),
          _detailRow('Academic Year', data['academicYear'] ?? 'N/A'),
          const SizedBox(height: 16),
          Divider(color: _G4.purple.withOpacity(0.12)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
                child:
                    _actionBtn('Edit', _G4.blue, Icons.edit_rounded, onTap: () {
              Navigator.pop(context);
              _editPayment(context, docId, data);
            })),
            const SizedBox(width: 10),
            Expanded(
                child: _actionBtn(
                    'Delete', _G4.red, Icons.delete_outline_rounded, onTap: () {
              Navigator.pop(context);
              _deletePayment(
                  context, docId, data['memberName'] ?? 'this record');
            })),
          ]),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  // ── EDIT PAYMENT ─────────────────────────────────────────
  void _editPayment(
      BuildContext context, String docId, Map<String, dynamic> data) {
    const months = [
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "January",
      "February",
      "March"
    ];
    int selIdx = data['fiscalIndex'] ?? 0;
    final amtCtrl = TextEditingController(text: '${data['amount'] ?? 500}');
    final fyCtrl =
        TextEditingController(text: data['academicYear'] ?? _currentFY);

    showDialog(
        context: context,
        builder: (_) => StatefulBuilder(
              builder: (ctx, setS) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                title: Text('Edit Payment — ${data['memberName'] ?? ''}',
                    style: _G4.poppins(size: 14, weight: FontWeight.w700)),
                content: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: amtCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          labelText: 'Amount (₹)', prefixText: '₹ ')),
                  const SizedBox(height: 12),
                  TextField(
                      controller: fyCtrl,
                      decoration: const InputDecoration(
                          labelText: 'Academic Year',
                          hintText: 'e.g. 2026-2027')),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<int>(
                    value: selIdx,
                    decoration: const InputDecoration(labelText: 'Month'),
                    items: months
                        .asMap()
                        .entries
                        .map((e) => DropdownMenuItem(
                            value: e.key, child: Text(e.value)))
                        .toList(),
                    onChanged: (v) => setS(() => selIdx = v!),
                  ),
                ]),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Cancel')),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: _G4.purple,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    onPressed: () async {
                      await FirebaseFirestore.instance
                          .collection('contributions')
                          .doc(docId)
                          .update({
                        'amount':
                            double.tryParse(amtCtrl.text) ?? data['amount'],
                        'fiscalIndex': selIdx,
                        'month': months[selIdx],
                        'academicYear': fyCtrl.text.trim(),
                      });
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
                    child: const Text('SAVE',
                        style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ));
  }

  // ── DELETE PAYMENT ───────────────────────────────────────
  void _deletePayment(BuildContext context, String docId, String label) {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text('Delete Payment',
                  style: _G4.poppins(size: 15, weight: FontWeight.w700)),
              content: Text('Delete payment for $label? This cannot be undone.',
                  style: _G4.poppins(size: 13, color: _G4.midPurple)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _G4.red,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  onPressed: () async {
                    await FirebaseFirestore.instance
                        .collection('contributions')
                        .doc(docId)
                        .delete();
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: const Text('DELETE',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ));
  }

  // ══════════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════════
  Widget _detailRow(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: _G4.poppins(size: 12, color: _G4.midPurple)),
          Text(value, style: _G4.poppins(size: 12, weight: FontWeight.w700)),
        ]),
      );

  Widget _sectionHead(BuildContext context, String title, String action,
      {VoidCallback? onTap}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(title.toUpperCase(),
            style: TextStyle(
                color: _G4.midPurple,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8)),
        GestureDetector(
            onTap: onTap,
            child: Text(action,
                style: _G4.poppins(size: 10.5, color: _G4.purple))),
      ]),
    );
  }

  Widget _actionBtn(String label, Color color, IconData icon,
      {required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(11),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 6),
          Text(label,
              style: TextStyle(
                  color: color, fontWeight: FontWeight.w700, fontSize: 12)),
        ]),
      ),
    );
  }

  static String _shortYear(String month, String fy) {
    if (fy.isEmpty) return '';
    final parts = fy.split('-');
    if (parts.length != 2) return '';
    const endMonths = ['January', 'February', 'March'];
    final year = endMonths.contains(month) ? parts[1] : parts[0];
    return year.length >= 4 ? year.substring(2) : year;
  }

  String _monthName() {
    const m = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return m[DateTime.now().month - 1];
  }

  static dynamic _safe(DocumentSnapshot d, String key) {
    try {
      return (d.data() as Map)[key];
    } catch (_) {
      return null;
    }
  }

  static Map<String, dynamic> _safeMap(DocumentSnapshot d) {
    try {
      return d.data() as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }
}

// ── Data models ───────────────────────────────────────────────
class _ChipDef {
  final String emoji, value, label;
  final Color color;
  final VoidCallback onTap;
  const _ChipDef(this.emoji, this.value, this.label, this.color, this.onTap);
}

class _BannerItem {
  final String tag, title, subtitle, emoji;
  final Color tagColor;
  final List<Color> gradients;
  final String? imageUrl;
  const _BannerItem(
      {required this.tag,
      required this.tagColor,
      required this.emoji,
      required this.gradients,
      required this.title,
      required this.subtitle,
      this.imageUrl});
}
