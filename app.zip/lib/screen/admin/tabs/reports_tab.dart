// ══════════════════════════════════════════════════════════════
// reports_tab.dart
// Tab 4 — Reports (Income PDF · Defaulters PDF · Ledger · Alerts)
// LLCET Admin Panel · G4 Design
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../utils/g4_theme.dart';

class ReportsTab extends StatelessWidget {
  final String selectedFY;
  const ReportsTab({super.key, required this.selectedFY});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .where('status', isEqualTo: 'approved')
          .snapshots(),
      builder: (_, userSnap) => StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('contributions')
            .where('academicYear', isEqualTo: selectedFY)
            .snapshots(),
        builder: (_, paySnap) {
          if (!userSnap.hasData || !paySnap.hasData) {
            return const Center(
                child: CircularProgressIndicator(color: G4.purple));
          }

          final int curMonth = DateTime.now().month >= 4
              ? DateTime.now().month - 4
              : DateTime.now().month + 8;

          final redAlerts = userSnap.data!.docs.where((u) {
            final paid = paySnap.data!.docs
                .where((p) =>
                    (p.data() as Map<String, dynamic>)['uid'] == u.id &&
                    p['status'] == 'Paid')
                .length;
            return (curMonth + 1) - paid >= 3;
          }).toList();

          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(16),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // ── Active Members Card ──
              Container(
                padding: const EdgeInsets.all(16),
                decoration: G4.glassCard(),
                child: Row(children: [
                  Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: G4.purple.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12)),
                      child: Icon(Icons.people_alt_rounded,
                          color: G4.purple, size: 22)),
                  const SizedBox(width: 14),
                  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${userSnap.data!.docs.length}',
                            style:
                                G4.poppins(size: 22, weight: FontWeight.w800)),
                        Text('Active Members',
                            style: G4.poppins(size: 11.5, color: G4.midPurple)),
                      ]),
                ]),
              ),

              const SizedBox(height: 16),
              Text('Generate Reports',
                  style: G4.poppins(size: 13, weight: FontWeight.w700)),
              const SizedBox(height: 10),

              // ── Report Tiles ──
              _reportTile(
                  context,
                  'Monthly Income Report',
                  'Month-wise collection for $selectedFY',
                  Icons.calendar_month_rounded,
                  () => _genIncomePDF(paySnap.data!.docs, selectedFY)),
              _reportTile(
                  context,
                  'Defaulters List',
                  'Members with missed payments',
                  Icons.person_off_rounded,
                  () => _genDefaultersPDF(
                      userSnap.data!.docs, paySnap.data!.docs, curMonth)),
              _reportTile(
                  context,
                  'Member Payment Ledger',
                  'Individual payment history',
                  Icons.menu_book_rounded,
                  () => _showLedgerSearch(
                      context, userSnap.data!.docs, paySnap.data!.docs)),
              _reportTile(
                  context,
                  'Annual Summary',
                  'Full year overview — $selectedFY',
                  Icons.summarize_rounded,
                  () => _genIncomePDF(paySnap.data!.docs, selectedFY)),

              // ── Priority Alerts ──
              if (redAlerts.isNotEmpty) ...[
                const SizedBox(height: 20),
                Row(children: [
                  Icon(Icons.warning_amber_rounded, color: G4.red, size: 17),
                  const SizedBox(width: 6),
                  Text('Priority Alerts (3+ Missed)',
                      style: TextStyle(
                          color: G4.red,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5)),
                ]),
                const SizedBox(height: 10),
                ...redAlerts.map((u) {
                  final d = u.data() as Map<String, dynamic>;
                  final paid = paySnap.data!.docs
                      .where((p) =>
                          (p.data() as Map<String, dynamic>)['uid'] == u.id &&
                          p['status'] == 'Paid')
                      .length;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: G4.red.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: G4.red.withOpacity(0.2)),
                    ),
                    child: Row(children: [
                      Icon(Icons.notification_important_rounded,
                          color: G4.red, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                            Text(d['name'] ?? 'Unknown',
                                style: G4.poppins(
                                    size: 13, weight: FontWeight.w600)),
                            Text('${(curMonth + 1) - paid} months missed',
                                style:
                                    TextStyle(color: G4.red, fontSize: 11.5)),
                          ])),
                    ]),
                  );
                }),
              ],
              const SizedBox(height: 28),
            ]),
          );
        },
      ),
    );
  }

  // ── Report Tile ──────────────────────────────────────────
  Widget _reportTile(BuildContext context, String title, String sub,
      IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: G4.glassCard(),
        child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          leading: Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                  color: G4.purple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: G4.purple, size: 20)),
          title:
              Text(title, style: G4.poppins(size: 13, weight: FontWeight.w600)),
          subtitle: Text(sub, style: G4.poppins(size: 11, color: G4.midPurple)),
          trailing: Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                  color: G4.red.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(8)),
              child:
                  Icon(Icons.picture_as_pdf_rounded, color: G4.red, size: 18)),
        ),
      ),
    );
  }

  // ── Income PDF ───────────────────────────────────────────
  Future<void> _genIncomePDF(
      List<QueryDocumentSnapshot> docs, String fy) async {
    const months = [
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "January",
      "February",
      "March"
    ];
    final pdf = pw.Document();
    double grand = 0;
    pdf.addPage(pw.Page(
        build: (ctx) => pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('LLCET TRUST — INCOME REPORT ($fy)',
                      style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold, fontSize: 18)),
                  pw.SizedBox(height: 6),
                  pw.Text(
                      'Generated: ${DateTime.now().toString().substring(0, 16)}',
                      style: const pw.TextStyle(fontSize: 10)),
                  pw.SizedBox(height: 20),
                  pw.Table.fromTextArray(
                      headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                      headers: ['Month', 'Collection (₹)'],
                      data: months.asMap().entries.map((e) {
                        final t = docs
                            .where((d) =>
                                (d.data() as Map)['fiscalIndex'] == e.key &&
                                d['status'] == 'Paid')
                            .fold(
                                0.0,
                                (s, d) =>
                                    s +
                                    ((d.data() as Map)['amount'] as num? ?? 0));
                        grand += t;
                        return [e.value, '₹${t.toStringAsFixed(2)}'];
                      }).toList()),
                  pw.SizedBox(height: 16),
                  pw.Align(
                      alignment: pw.Alignment.centerRight,
                      child: pw.Text(
                          'Grand Total: ₹${grand.toStringAsFixed(2)}',
                          style: pw.TextStyle(
                              fontWeight: pw.FontWeight.bold, fontSize: 14))),
                ])));
    await Printing.sharePdf(
        bytes: await pdf.save(), filename: 'Income_Report_$fy.pdf');
  }

  // ── Defaulters PDF ───────────────────────────────────────
  Future<void> _genDefaultersPDF(List<QueryDocumentSnapshot> users,
      List<QueryDocumentSnapshot> pays, int curMonth) async {
    final pdf = pw.Document();
    pdf.addPage(pw.MultiPage(
        build: (ctx) => [
              pw.Text('LLCET TRUST — DEFAULTERS LIST',
                  style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold, fontSize: 18)),
              pw.SizedBox(height: 6),
              pw.Text(
                  'Generated: ${DateTime.now().toString().substring(0, 16)}',
                  style: const pw.TextStyle(fontSize: 10)),
              pw.SizedBox(height: 20),
              pw.Table.fromTextArray(
                  headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                  headers: ['Name', 'Phone', 'Paid', 'Missed', 'Status'],
                  data: users.expand((u) {
                    final d = u.data() as Map<String, dynamic>;
                    final paid = pays
                        .where((p) =>
                            (p.data() as Map<String, dynamic>)['uid'] == u.id &&
                            p['status'] == 'Paid')
                        .length;
                    final missed = (curMonth + 1) - paid;
                    if (missed <= 0) return <List<String>>[];
                    return [
                      [
                        d['name'] ?? '',
                        d['phone'] ?? '',
                        '$paid/12',
                        '$missed',
                        missed >= 3 ? '🚨 ALERT' : 'Pending'
                      ]
                    ];
                  }).toList()),
            ]));
    await Printing.sharePdf(
        bytes: await pdf.save(), filename: 'Defaulters_Report.pdf');
  }

  // ── Ledger Search Dialog ─────────────────────────────────
  void _showLedgerSearch(BuildContext context,
      List<QueryDocumentSnapshot> users, List<QueryDocumentSnapshot> pays) {
    String s = '';
    showDialog(
        context: context,
        builder: (_) => StatefulBuilder(
              builder: (ctx, setS) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                title: Text('Select Member',
                    style: G4.poppins(size: 15, weight: FontWeight.w700)),
                content: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      onChanged: (v) => setS(() => s = v.toLowerCase()),
                      style: G4.poppins(size: 13),
                      decoration:
                          const InputDecoration(hintText: 'Search name...')),
                  SizedBox(
                      height: 240,
                      width: double.maxFinite,
                      child: ListView(
                          children: users
                              .where((u) => ((u.data() as Map)['name'] ?? '')
                                  .toString()
                                  .toLowerCase()
                                  .contains(s))
                              .map((u) => ListTile(
                                    title: Text((u.data() as Map)['name'] ?? '',
                                        style: G4.poppins(size: 13)),
                                    onTap: () {
                                      Navigator.pop(ctx);
                                      _genLedger(u, pays);
                                    },
                                  ))
                              .toList())),
                ]),
              ),
            ));
  }

  // ── Ledger PDF ───────────────────────────────────────────
  Future<void> _genLedger(
      DocumentSnapshot user, List<QueryDocumentSnapshot> pays) async {
    final d = user.data() as Map<String, dynamic>;
    final up = pays
        .where((p) =>
            (p.data() as Map<String, dynamic>)['uid'] == user.id &&
            p['status'] == 'Paid')
        .toList()
      ..sort((a, b) {
        final ai = (a.data() as Map)['fiscalIndex'] ?? 0;
        final bi = (b.data() as Map)['fiscalIndex'] ?? 0;
        return (ai as int).compareTo(bi as int);
      });

    final total =
        up.fold(0.0, (s, p) => s + ((p.data() as Map)['amount'] as num? ?? 0));

    final pdf = pw.Document();
    pdf.addPage(pw.Page(
        build: (ctx) => pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('LLCET — MEMBER PAYMENT LEDGER',
                      style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold, fontSize: 18)),
                  pw.SizedBox(height: 6),
                  pw.Text('Member : ${d['name'] ?? ''}'),
                  pw.Text('Phone  : ${d['phone'] ?? ''}'),
                  pw.Text(
                      'Generated: ${DateTime.now().toString().substring(0, 16)}',
                      style: const pw.TextStyle(fontSize: 10)),
                  pw.SizedBox(height: 20),
                  pw.Table.fromTextArray(
                      headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                      headers: ['Month', 'Amount', 'Txn ID', 'Status'],
                      data: up
                          .map((p) => [
                                p['month'] ?? '',
                                '₹${p['amount'] ?? 0}',
                                p['transactionId'] ?? '',
                                p['status'] ?? ''
                              ])
                          .toList()),
                  pw.SizedBox(height: 16),
                  pw.Align(
                      alignment: pw.Alignment.centerRight,
                      child: pw.Text('Total Paid: ₹${total.toStringAsFixed(2)}',
                          style: pw.TextStyle(
                              fontWeight: pw.FontWeight.bold, fontSize: 13))),
                ])));
    await Printing.sharePdf(
        bytes: await pdf.save(),
        filename: 'Ledger_${d['name'] ?? 'Member'}.pdf');
  }
}
