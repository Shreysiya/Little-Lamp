// ══════════════════════════════════════════════════════════════
// payments_tab.dart
// Tab 3 — Payments (Pending Verification + Paid History)
// LLCET Admin Panel · G4 Design
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';

// ── G4 Design Tokens ─────────────────────────────────────────
class _G4 {
  static const bg = Color(0xFFEDE6FF);
  static const deepPurple = Color(0xFF2D1B4E);
  static const purple = Color(0xFF5B2D8E);
  static const midPurple = Color(0xFF6B5A8A);
  static const orange = Color(0xFFF5840C);
  static const blue = Color(0xFF5BAEE8);
  static const green = Color(0xFF2E7D52);
  static const red = Color(0xFFB00020);

  static BoxDecoration glassCard({Color? shadow}) => BoxDecoration(
        color: Colors.white.withOpacity(0.62),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.9), width: 1.5),
        boxShadow: [
          BoxShadow(
              color: (shadow ?? purple).withOpacity(0.09),
              blurRadius: 16,
              offset: const Offset(0, 4))
        ],
      );

  static TextStyle poppins(
          {double size = 14,
          FontWeight weight = FontWeight.w600,
          Color? color}) =>
      GoogleFonts.poppins(
          fontSize: size, fontWeight: weight, color: color ?? deepPurple);
}

// ── Shared Bottom Sheet ───────────────────────────────────────
class _G4Sheet extends StatelessWidget {
  final Widget child;
  const _G4Sheet({required this.child});
  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFFEDE6FF),
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: const Color(0xFF5B2D8E).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 20),
          child,
        ]),
      );
}

// ══════════════════════════════════════════════════════════════
// PaymentsTab — public class (used in admin_home.dart)
// ══════════════════════════════════════════════════════════════
class PaymentsTab extends StatefulWidget {
  final String selectedFY;
  const PaymentsTab({super.key, required this.selectedFY});
  @override
  State<PaymentsTab> createState() => _PaymentsTabState();
}

class _PaymentsTabState extends State<PaymentsTab>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // ── summary strip ────────────────────────────────────
      _SummaryStrip(selectedFY: widget.selectedFY),
      // ── tab bar ──────────────────────────────────────────
      Container(
        color: Colors.white.withOpacity(0.5),
        child: TabBar(
          controller: _tabCtrl,
          labelColor: _G4.purple,
          unselectedLabelColor: _G4.midPurple,
          indicatorColor: _G4.purple,
          indicatorWeight: 2.5,
          labelStyle:
              const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          unselectedLabelStyle:
              const TextStyle(fontWeight: FontWeight.w500, fontSize: 13),
          tabs: const [
            Tab(text: 'Pending Verification'),
            Tab(text: 'Payment History'),
          ],
        ),
      ),
      Expanded(
        child: TabBarView(controller: _tabCtrl, children: [
          _PendingVerificationView(selectedFY: widget.selectedFY),
          _PaymentHistoryView(selectedFY: widget.selectedFY),
        ]),
      ),
    ]);
  }
}

// ══════════════════════════════════════════════════════════════
// SUMMARY STRIP — total collected + awaiting count
// ══════════════════════════════════════════════════════════════
class _SummaryStrip extends StatelessWidget {
  final String selectedFY;
  const _SummaryStrip({required this.selectedFY});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('contributions')
          .where('academicYear', isEqualTo: selectedFY)
          .snapshots(),
      builder: (_, snap) {
        final docs = snap.hasData ? snap.data!.docs : <QueryDocumentSnapshot>[];
        final paid = docs.where((d) => _safe(d, 'status') == 'Paid');
        final awaiting =
            docs.where((d) => _safe(d, 'status') == 'Awaiting Approval').length;
        final total =
            paid.fold(0.0, (s, d) => s + (_safeMap(d)['amount'] as num? ?? 0));

        return Container(
          margin: const EdgeInsets.fromLTRB(16, 10, 16, 8),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF3B1A6B), Color(0xFF5B2D8E)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                  color: _G4.purple.withOpacity(0.35),
                  blurRadius: 16,
                  offset: const Offset(0, 6))
            ],
          ),
          child: Row(children: [
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text('TOTAL COLLECTED',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 9,
                          letterSpacing: 1.2,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text('₹${total.toStringAsFixed(0)}',
                      style: _G4.poppins(
                          size: 22,
                          weight: FontWeight.w900,
                          color: Colors.white)),
                  Text(selectedFY,
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.5), fontSize: 10)),
                ])),
            Container(
                width: 1, height: 50, color: Colors.white.withOpacity(0.15)),
            const SizedBox(width: 16),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('AWAITING',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 9,
                      letterSpacing: 1.2,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text('$awaiting',
                  style: _G4.poppins(
                      size: 22,
                      weight: FontWeight.w900,
                      color: awaiting > 0 ? _G4.orange : Colors.white)),
              Text('Pending',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.5), fontSize: 10)),
            ]),
          ]),
        );
      },
    );
  }

  static dynamic _safe(DocumentSnapshot d, String key) {
    try {
      return (d.data() as Map)[key];
    } catch (_) {
      return null;
    }
  }

  static Map<String, dynamic> _safeMap(DocumentSnapshot d) {
    try {
      return d.data() as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }
}

// ══════════════════════════════════════════════════════════════
// TAB A — PENDING VERIFICATION
// ══════════════════════════════════════════════════════════════
class _PendingVerificationView extends StatelessWidget {
  final String selectedFY;
  const _PendingVerificationView({required this.selectedFY});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('contributions')
          .where('status', isEqualTo: 'Awaiting Approval')
          .snapshots(),
      builder: (context, snap) {
        if (!snap.hasData)
          return const Center(
              child: CircularProgressIndicator(color: _G4.purple));

        if (snap.data!.docs.isEmpty) {
          return Center(
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.check_circle_outline_rounded,
                  size: 56, color: _G4.green.withOpacity(0.4)),
              const SizedBox(height: 14),
              Text('All Verified!',
                  style: _G4.poppins(size: 17, weight: FontWeight.w700)),
              Text('No pending payments to review',
                  style: _G4.poppins(size: 12, color: _G4.midPurple)),
            ]),
          );
        }

        return ListView.builder(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
          itemCount: snap.data!.docs.length,
          itemBuilder: (context, i) => _PendingCard(doc: snap.data!.docs[i]),
        );
      },
    );
  }
}

// ── Pending Card ─────────────────────────────────────────────
class _PendingCard extends StatelessWidget {
  final QueryDocumentSnapshot doc;
  const _PendingCard({required this.doc});

  @override
  Widget build(BuildContext context) {
    final data = _safeMap(doc);
    final name = data['memberName'] ?? data['uid'] ?? 'Unknown';
    final month = data['month'] ?? '';
    final amount = data['amount'] ?? 0;
    final txnId = data['transactionId'] ?? data['method'] ?? 'N/A';
    final fy = data['academicYear'] ?? '';
    final imgUrl = data['proofUrl'] ?? data['receiptUrl'];

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: _G4.glassCard(shadow: _G4.orange),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── header row ──────────────────────────────────────
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$month — ₹$amount',
                style: _G4.poppins(size: 15, weight: FontWeight.w700)),
            const SizedBox(height: 3),
            Text(name, style: _G4.poppins(size: 12, color: _G4.midPurple)),
          ]),
          _StatusBadge(label: 'Pending', color: _G4.orange),
        ]),
        const SizedBox(height: 8),
        // ── meta info ───────────────────────────────────────
        _metaRow(Icons.receipt_long_rounded, 'Txn: $txnId'),
        if (fy.isNotEmpty) _metaRow(Icons.calendar_today_rounded, 'FY: $fy'),
        // ── proof image thumbnail ───────────────────────────
        if (imgUrl != null) ...[
          const SizedBox(height: 10),
          GestureDetector(
            onTap: () => _showProof(context, imgUrl),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(imgUrl,
                  height: 100,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            ),
          ),
        ],
        const SizedBox(height: 14),
        // ── action buttons ──────────────────────────────────
        Row(children: [
          Expanded(
              child: _OutlineBtn(
            label: 'REJECT',
            color: _G4.red,
            onTap: () => _confirmReject(context, doc.id, name),
          )),
          const SizedBox(width: 10),
          Expanded(
              flex: 2,
              child: _FilledBtn(
                label: 'APPROVE PAYMENT',
                color: _G4.green,
                icon: Icons.check_rounded,
                onTap: () async {
                  await FirebaseFirestore.instance
                      .collection('contributions')
                      .doc(doc.id)
                      .update({
                    'status': 'Paid',
                    'approvedAt': FieldValue.serverTimestamp()
                  });
                },
              )),
        ]),
      ]),
    );
  }

  void _showProof(BuildContext context, String url) {
    showDialog(
        context: context,
        builder: (_) => Dialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.network(url, fit: BoxFit.contain),
              ),
            ));
  }

  void _confirmReject(BuildContext context, String docId, String label) {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text('Reject Payment',
                  style: _G4.poppins(size: 15, weight: FontWeight.w700)),
              content: Text('Reject this payment from $label?',
                  style: _G4.poppins(size: 13, color: _G4.midPurple)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _G4.red,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  onPressed: () async {
                    await FirebaseFirestore.instance
                        .collection('contributions')
                        .doc(docId)
                        .update({
                      'status': 'Rejected',
                      'rejectedAt': FieldValue.serverTimestamp()
                    });
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: const Text('REJECT',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ));
  }

  Widget _metaRow(IconData icon, String text) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Row(children: [
          Icon(icon, size: 13, color: _G4.midPurple),
          const SizedBox(width: 6),
          Text(text,
              style: TextStyle(
                  color: _G4.midPurple.withOpacity(0.75), fontSize: 10.5)),
        ]),
      );

  static Map<String, dynamic> _safeMap(DocumentSnapshot d) {
    try {
      return d.data() as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }
}

// ══════════════════════════════════════════════════════════════
// TAB B — PAYMENT HISTORY
// ══════════════════════════════════════════════════════════════
class _PaymentHistoryView extends StatefulWidget {
  final String selectedFY;
  const _PaymentHistoryView({required this.selectedFY});
  @override
  State<_PaymentHistoryView> createState() => _PaymentHistoryViewState();
}

class _PaymentHistoryViewState extends State<_PaymentHistoryView> {
  String _search = '';
  String _filterStatus = 'All'; // All | Paid | Rejected

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('contributions')
          .where('academicYear', isEqualTo: widget.selectedFY)
          .snapshots(),
      builder: (_, snap) {
        if (!snap.hasData)
          return const Center(
              child: CircularProgressIndicator(color: _G4.purple));

        var docs = snap.data!.docs.where((d) {
          final data = d.data() as Map;
          final name = (data['memberName'] ?? data['uid'] ?? '')
              .toString()
              .toLowerCase();
          final month = (data['month'] ?? '').toString().toLowerCase();
          final matchSearch = _search.isEmpty ||
              name.contains(_search) ||
              month.contains(_search);
          final status = (data['status'] ?? '').toString();
          final matchFilter = _filterStatus == 'All' || status == _filterStatus;
          return matchSearch && matchFilter;
        }).toList()
          ..sort((a, b) {
            final aT = (a.data() as Map)['submittedAt'];
            final bT = (b.data() as Map)['submittedAt'];
            if (aT == null || bT == null) return 0;
            return (bT as dynamic).compareTo(aT);
          });

        return Column(children: [
          // ── search + filter bar ───────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
            child: Row(children: [
              Expanded(
                  child: Container(
                height: 42,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.75),
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(color: _G4.purple.withOpacity(0.12)),
                ),
                child: TextField(
                  onChanged: (v) => setState(() => _search = v.toLowerCase()),
                  style: _G4.poppins(size: 12),
                  decoration: InputDecoration(
                    hintText: 'Search member / month...',
                    hintStyle: TextStyle(color: _G4.midPurple, fontSize: 12),
                    prefixIcon: Icon(Icons.search_rounded,
                        color: _G4.purple.withOpacity(0.5), size: 18),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 11),
                  ),
                ),
              )),
              const SizedBox(width: 8),
              _FilterChip(
                  label: 'All',
                  selected: _filterStatus == 'All',
                  onTap: () => setState(() => _filterStatus = 'All')),
              _FilterChip(
                  label: 'Paid',
                  selected: _filterStatus == 'Paid',
                  onTap: () => setState(() => _filterStatus = 'Paid'),
                  color: _G4.green),
              _FilterChip(
                  label: 'Rejected',
                  selected: _filterStatus == 'Rejected',
                  onTap: () => setState(() => _filterStatus = 'Rejected'),
                  color: _G4.red),
            ]),
          ),
          // ── count badge ────────────────────────────────────
          Padding(
            padding: const EdgeInsets.only(left: 16, bottom: 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text('${docs.length} records',
                  style: _G4.poppins(size: 10.5, color: _G4.midPurple)),
            ),
          ),
          // ── list ──────────────────────────────────────────
          Expanded(
              child: docs.isEmpty
                  ? Center(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                          Icon(Icons.inbox_rounded,
                              size: 48, color: _G4.purple.withOpacity(0.2)),
                          const SizedBox(height: 10),
                          Text('No records found',
                              style:
                                  _G4.poppins(size: 14, color: _G4.midPurple)),
                        ]))
                  : ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 80),
                      itemCount: docs.length,
                      itemBuilder: (_, i) => _HistoryCard(doc: docs[i]),
                    )),
        ]);
      },
    );
  }
}

// ── History Card ─────────────────────────────────────────────
class _HistoryCard extends StatelessWidget {
  final QueryDocumentSnapshot doc;
  const _HistoryCard({required this.doc});

  @override
  Widget build(BuildContext context) {
    final data = doc.data() as Map<String, dynamic>;
    final name = data['memberName'] ?? data['uid'] ?? 'Unknown';
    final month = data['month'] ?? '';
    final amount = data['amount'] ?? 0;
    final method = data['method'] ?? data['transactionId'] ?? '';
    final status = data['status'] ?? '';
    final isPaid = status == 'Paid';

    return GestureDetector(
      onTap: () => _showDetail(context, data, doc.id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: _G4.glassCard(shadow: isPaid ? _G4.green : _G4.red),
        child: Row(children: [
          // avatar
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: (isPaid ? _G4.green : _G4.red).withOpacity(0.1),
            ),
            child: Center(
                child: Text(
              name.isNotEmpty ? name[0].toUpperCase() : '?',
              style: TextStyle(
                  color: isPaid ? _G4.green : _G4.red,
                  fontSize: 15,
                  fontWeight: FontWeight.w800),
            )),
          ),
          const SizedBox(width: 12),
          // details
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(name,
                    style: _G4.poppins(size: 12.5, weight: FontWeight.w600),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                Text('$month · $method',
                    style: TextStyle(color: _G4.midPurple, fontSize: 10)),
              ])),
          // amount + badge
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('₹$amount',
                style: _G4.poppins(
                    size: 13,
                    weight: FontWeight.w700,
                    color: isPaid ? _G4.green : _G4.red)),
            const SizedBox(height: 4),
            _StatusBadge(
                label: status,
                color: isPaid ? _G4.green : _G4.red,
                small: true),
          ]),
        ]),
      ),
    );
  }

  void _showDetail(
      BuildContext context, Map<String, dynamic> data, String docId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _G4Sheet(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                  shape: BoxShape.circle, color: _G4.green.withOpacity(0.12)),
              child: const Center(
                  child: Text('💳', style: TextStyle(fontSize: 26)))),
          const SizedBox(height: 14),
          Text('Payment Details',
              style: _G4.poppins(size: 16, weight: FontWeight.w700)),
          const SizedBox(height: 16),
          _detailRow('Member', data['memberName'] ?? data['uid'] ?? 'N/A'),
          _detailRow('Month', data['month'] ?? 'N/A'),
          _detailRow('Amount', '₹${data['amount'] ?? 0}'),
          _detailRow(
              'Method', data['method'] ?? data['transactionId'] ?? 'N/A'),
          _detailRow('Status', data['status'] ?? 'N/A'),
          _detailRow('Academic Year', data['academicYear'] ?? 'N/A'),
          const SizedBox(height: 16),
          Divider(color: _G4.purple.withOpacity(0.12)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
                child: _OutlineBtn(
                    label: 'Edit',
                    color: _G4.blue,
                    icon: Icons.edit_rounded,
                    onTap: () {
                      Navigator.pop(context);
                      _editPayment(context, docId, data);
                    })),
            const SizedBox(width: 10),
            Expanded(
                child: _OutlineBtn(
                    label: 'Delete',
                    color: _G4.red,
                    icon: Icons.delete_outline_rounded,
                    onTap: () {
                      Navigator.pop(context);
                      _deletePayment(
                          context, docId, data['memberName'] ?? 'this record');
                    })),
          ]),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  void _editPayment(
      BuildContext context, String docId, Map<String, dynamic> data) {
    const months = [
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
      "January",
      "February",
      "March"
    ];
    int selIdx = data['fiscalIndex'] ?? 0;
    final amtCtrl = TextEditingController(text: '${data['amount'] ?? 500}');
    final fyCtrl = TextEditingController(text: data['academicYear'] ?? '');
    showDialog(
        context: context,
        builder: (_) => StatefulBuilder(
              builder: (ctx, setS) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                title: Text('Edit Payment',
                    style: _G4.poppins(size: 14, weight: FontWeight.w700)),
                content: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: amtCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          labelText: 'Amount (₹)', prefixText: '₹ ')),
                  const SizedBox(height: 12),
                  TextField(
                      controller: fyCtrl,
                      decoration:
                          const InputDecoration(labelText: 'Academic Year')),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<int>(
                    value: selIdx,
                    decoration: const InputDecoration(labelText: 'Month'),
                    items: months
                        .asMap()
                        .entries
                        .map((e) => DropdownMenuItem(
                            value: e.key, child: Text(e.value)))
                        .toList(),
                    onChanged: (v) => setS(() => selIdx = v!),
                  ),
                ]),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Cancel')),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: _G4.purple,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    onPressed: () async {
                      await FirebaseFirestore.instance
                          .collection('contributions')
                          .doc(docId)
                          .update({
                        'amount':
                            double.tryParse(amtCtrl.text) ?? data['amount'],
                        'fiscalIndex': selIdx,
                        'month': months[selIdx],
                        'academicYear': fyCtrl.text.trim(),
                      });
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
                    child: const Text('SAVE',
                        style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ));
  }

  void _deletePayment(BuildContext context, String docId, String label) {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text('Delete Payment',
                  style: _G4.poppins(size: 15, weight: FontWeight.w700)),
              content: Text('Delete payment for $label? This cannot be undone.',
                  style: _G4.poppins(size: 13, color: _G4.midPurple)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _G4.red,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  onPressed: () async {
                    await FirebaseFirestore.instance
                        .collection('contributions')
                        .doc(docId)
                        .delete();
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: const Text('DELETE',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ));
  }

  static Widget _detailRow(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: _G4.poppins(size: 12, color: _G4.midPurple)),
          Text(value, style: _G4.poppins(size: 12, weight: FontWeight.w700)),
        ]),
      );
}

// ══════════════════════════════════════════════════════════════
// SHARED SMALL WIDGETS
// ══════════════════════════════════════════════════════════════
class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final bool small;
  const _StatusBadge(
      {required this.label, required this.color, this.small = false});

  @override
  Widget build(BuildContext context) => Container(
        padding: EdgeInsets.symmetric(
            horizontal: small ? 7 : 10, vertical: small ? 3 : 4),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Text(label,
            style: TextStyle(
                color: color,
                fontSize: small ? 9 : 10,
                fontWeight: FontWeight.w700)),
      );
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? color;
  const _FilterChip(
      {required this.label,
      required this.selected,
      required this.onTap,
      this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? _G4.purple;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.only(left: 4),
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? c.withOpacity(0.15) : Colors.white.withOpacity(0.6),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: selected ? c : c.withOpacity(0.2)),
        ),
        child: Text(label,
            style: TextStyle(
                color: c,
                fontSize: 10,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500)),
      ),
    );
  }
}

class _FilledBtn extends StatelessWidget {
  final String label;
  final Color color;
  final IconData? icon;
  final VoidCallback onTap;
  const _FilledBtn(
      {required this.label,
      required this.color,
      required this.onTap,
      this.icon});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          height: 42,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                  color: color.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 3))
            ],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (icon != null) Icon(icon, color: Colors.white, size: 16),
            if (icon != null) const SizedBox(width: 6),
            Text(label,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 11,
                    letterSpacing: 0.6)),
          ]),
        ),
      );
}

class _OutlineBtn extends StatelessWidget {
  final String label;
  final Color color;
  final IconData? icon;
  final VoidCallback onTap;
  const _OutlineBtn(
      {required this.label,
      required this.color,
      required this.onTap,
      this.icon});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          height: 42,
          decoration: BoxDecoration(
            color: color.withOpacity(0.07),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (icon != null) Icon(icon, color: color, size: 15),
            if (icon != null) const SizedBox(width: 5),
            Text(label,
                style: TextStyle(
                    color: color, fontWeight: FontWeight.w700, fontSize: 11)),
          ]),
        ),
      );
}
